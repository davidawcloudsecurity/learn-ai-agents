# Implementation Plan

## Phase 1: System Documentation and Setup

- [ ] 1. Setup environment and validate existing RAG service
  - Verify the `chatbot-feature-validator.py` script exists in `mlu-agcod-lab/` directory
  - Create or update `.env` file in `mlu-agcod-lab/` with `CHAT_ENDPOINT` environment variable
  - Execute the validator script in fallback mode to test the existing RAG service: `cd mlu-agcod-lab && uv run chatbot-feature-validator.py --query "What is AWS Lambda?"`
  - Verify the RAG service responds successfully with relevant information
  - Document any configuration issues or troubleshooting steps needed
  - Confirm AWS credentials and permissions are properly configured
  - _Requirements: 1.1, 1.2, 1.3, 1.4, 1.5_

## Phase 2: Infrastructure and Data Layer

- [ ] 2. Update CDK infrastructure to add DynamoDB table
- [ ] 2.1 Add DynamoDB table definition to CDK stack
  - Add DynamoDB table definition to `src/<YourCDKPackage>/lib/serviceStack.ts`
  - Configure table with partition key `session_id` (String) and sort key `message_id` (String)
  - Set table name pattern as `${serviceName}-ChatSessions`
  - Configure billing mode as PAY_PER_REQUEST for cost efficiency
  - Grant Lambda function read and write permissions to the DynamoDB table
  - Add environment variable `CHAT_SESSIONS_TABLE_NAME` to Lambda function configuration
  - _Requirements: 2.1, 2.2, 2.3, 2.4, 2.5_

- [ ] 2.2 Write unit tests for CDK infrastructure changes
  - Create or update CDK test file in `src/<YourCDKPackage>/test/`
  - Test DynamoDB table is created with correct name pattern
  - Test table has correct partition key (session_id) and sort key (message_id)
  - Test table billing mode is PAY_PER_REQUEST
  - Test Lambda function has read/write permissions to the table
  - Test Lambda function has CHAT_SESSIONS_TABLE_NAME environment variable
  - Use CDK assertions library for infrastructure testing
  - _Requirements: 13.1, 13.2, 13.3, 13.4, 13.5_

- [ ] 2.3 Build CDK package and create commit
  - Execute `brazil-build release` to verify build succeeds
  - Execute `brazil-build test` to verify all unit tests pass
  - Create git commit with message: `feat: add DynamoDB table for chat sessions`
  - Optionally create code review if requested by user
  - _Requirements: 15.1, 15.2, 15.3, 15.4, 15.5_

- [ ] 3. Implement Pydantic data models for API requests and responses
- [ ] 3.1 Create models module with ChatRequest, MessageModel, ChatResponse, HistoryRequest, and HistoryResponse
  - Create new file `src/<YourLambdaPackage>/models.py`
  - Implement `ChatRequest` model with `message` (str, max 2048 chars) and optional `session_id` fields
  - Implement `MessageModel` with `message_id`, `message_type`, `message`, `timestamp`, optional `intent`, and optional `sources` fields
  - Implement `SourceDocument` model for RAG source tracking
  - Implement `ChatResponse` model with `session_id` and `messages` array
  - Implement `HistoryRequest` model with required `session_id` field
  - Implement `HistoryResponse` model with `session_id` and `messages` array
  - Add Pydantic validation rules including regex patterns for ULID format
  - Add `to_api_response()` method to MessageModel for proper field mapping
  - _Requirements: 3.1, 3.2, 3.3, 3.4, 3.5, 3.6, 3.7_

- [ ] 3.2 Write unit tests for data models
  - Create `tests/test_models.py` with comprehensive model validation tests
  - Test valid request/response formats with correct field values
  - Test invalid formats including missing required fields, invalid field types, and constraint violations
  - Test ULID pattern validation for session_id and message_id fields
  - Test message length validation (2048 character maximum)
  - Test message_type enum validation ("HUMAN" or "BOT")
  - Test intent enum validation ("CHAT" or "QUERY")
  - Test to_api_response() method returns correct field names
  - Use pytest fixtures for reusable test data
  - _Requirements: 13.1, 13.2, 13.3, 13.4, 13.5_

- [ ] 3.3 Run release build and create commit
  - Execute `brazil-build release` to verify build succeeds
  - Execute `brazil-build test` to verify all unit tests pass
  - Execute `brazil-build test --cover` to verify 80% minimum code coverage
  - Create git commit with message: `feat: implement Pydantic data models for chat API`
  - _Requirements: 15.1, 15.2, 15.3, 15.4, 15.5_

- [ ] 4. Implement custom exception classes for error handling
- [ ] 4.1 Create exceptions module with all custom exception types
  - Create new file `src/<YourLambdaPackage>/exceptions.py`
  - Implement base `ChatException` class with message and status_code attributes
  - Implement `ChatSessionNotFoundError` with HTTP 404 status code
  - Implement `ChatMessageTooLongError` with HTTP 400 status code
  - Implement `ChatServiceUnavailableError` with HTTP 503 status code
  - Implement `GuardrailInterventionError` with HTTP 400 status code
  - Implement `ChatTokenLimitExceededError` with HTTP 400 status code
  - _Requirements: 7.1, 7.2, 7.3, 7.4, 7.5, 7.6_

- [ ] 4.2 Write unit tests for exception classes
  - Create `tests/test_exceptions.py` with exception behavior tests
  - Test each exception type raises with correct status code
  - Test exception messages are properly formatted
  - Test exception inheritance from base ChatException class
  - Test exception serialization for API responses
  - _Requirements: 13.1, 13.2, 13.3, 13.4, 13.5_

- [ ] 4.3 Run release build and create commit
  - Execute `brazil-build release` to verify build succeeds
  - Execute `brazil-build test` to verify all unit tests pass
  - Execute `brazil-build test --cover` to verify 80% minimum code coverage
  - Create git commit with message: `feat: implement custom exception classes with HTTP status codes`
  - _Requirements: 15.1, 15.2, 15.3, 15.4, 15.5_

- [ ] 5. Implement DynamoDB repository for message persistence
- [ ] 5.1 Create repository module with DynamoDBChatRepository class
  - Create new file `src/<YourLambdaPackage>/repository.py`
  - Implement `__init__` method to initialize boto3 DynamoDB resource and table
  - Implement `save_message()` method to write messages to DynamoDB with error handling
  - Implement `get_session_messages()` method to query messages by session_id with ascending sort
  - Implement `session_exists()` method to check if a session has any messages
  - Add message length validation in save_message (raise ChatMessageTooLongError if > 2048 chars)
  - Add DynamoDB error handling (raise ChatServiceUnavailableError on failures)
  - Handle optional fields (intent, sources) properly in save and retrieve operations
  - _Requirements: 6.1, 6.2, 6.3, 6.4, 6.5_

- [ ] 5.2 Write unit tests for DynamoDB repository
  - Create `tests/test_repository.py` with mocked boto3 DynamoDB client
  - Test save_message() with valid messages using mocked put_item
  - Test save_message() raises ChatMessageTooLongError for messages > 2048 chars
  - Test save_message() raises ChatServiceUnavailableError on DynamoDB failures
  - Test get_session_messages() returns messages in chronological order using mocked query
  - Test get_session_messages() handles empty sessions correctly
  - Test session_exists() returns True for existing sessions and False otherwise
  - Use pytest-mock or unittest.mock for DynamoDB mocking
  - _Requirements: 13.1, 13.2, 13.3, 13.4, 13.5_

- [ ] 5.3 Run release build and create commit
  - Execute `brazil-build release` to verify build succeeds
  - Execute `brazil-build test` to verify all unit tests pass
  - Execute `brazil-build test --cover` to verify 80% minimum code coverage
  - Create git commit with message: `feat: implement DynamoDB repository with error handling`
  - _Requirements: 15.1, 15.2, 15.3, 15.4, 15.5_

- [ ] 6. Implement session manager with ULID generation
- [ ] 6.1 Create session manager module with SessionManager class
  - Create new file `src/<YourLambdaPackage>/session_manager.py`
  - Implement `__init__` method to accept DynamoDBChatRepository instance
  - Implement `generate_session_id()` method using ulid-py library with format `session_<ulid>`
  - Implement `generate_message_id()` method using ulid-py library with format `message_<ulid>`
  - Implement `validate_session_id()` method with regex pattern validation
  - Implement `create_or_get_session()` method to create new or retrieve existing sessions
  - Implement `save_message_pair()` method to save user and bot messages together
  - Add error handling for invalid session IDs and missing sessions
  - _Requirements: 5.1, 5.2, 5.3, 5.4, 5.5_

- [ ] 6.2 Write unit tests for session manager
  - Create `tests/test_session_manager.py` with mocked repository
  - Test generate_session_id() returns valid ULID format with session_ prefix
  - Test generate_message_id() returns valid ULID format with message_ prefix
  - Test validate_session_id() accepts valid formats and rejects invalid formats
  - Test create_or_get_session() creates new session when session_id is None
  - Test create_or_get_session() retrieves existing session when session_id is provided
  - Test create_or_get_session() raises ChatSessionNotFoundError for non-existent sessions
  - Test save_message_pair() saves both user and bot messages with correct attributes
  - _Requirements: 13.1, 13.2, 13.3, 13.4, 13.5_

- [ ] 6.3 Run release build and create commit
  - Execute `brazil-build release` to verify build succeeds
  - Execute `brazil-build test` to verify all unit tests pass
  - Execute `brazil-build test --cover` to verify 80% minimum code coverage
  - Create git commit with message: `feat: implement session manager with ULID generation`
  - _Requirements: 15.1, 15.2, 15.3, 15.4, 15.5_

## Phase 3: API Layer

- [ ] 7. Implement API handler functions for chat and history endpoints
- [ ] 7.1 Create handlers module with chat_handler and history_handler functions
  - Create new file `src/<YourLambdaPackage>/handlers.py`
  - Implement `chat_handler()` function to process /chat endpoint requests
  - Add request parsing and validation using ChatRequest model
  - Add session creation/retrieval logic using SessionManager
  - Add response formatting using ChatResponse model
  - Implement `history_handler()` function to process /chat/history endpoint requests
  - Add request parsing and validation using HistoryRequest model
  - Add session message retrieval logic
  - Add response formatting using HistoryResponse model
  - Add comprehensive error handling for all exception types with proper HTTP status codes
  - _Requirements: 4.1, 4.2, 4.3, 4.4, 4.5, 4.6, 4.7_

- [ ] 7.2 Write unit tests for API handlers
  - Create `tests/test_handlers.py` with mocked dependencies
  - Test chat_handler() with valid requests returns 200 status code
  - Test chat_handler() with invalid requests returns 400 status code
  - Test chat_handler() with missing session returns new session_id
  - Test chat_handler() with existing session continues conversation
  - Test history_handler() with valid session returns message history
  - Test history_handler() with non-existent session returns 404 status code
  - Test error handling for each exception type returns correct status codes
  - Mock SessionManager and HybridConversationChain for isolated testing
  - _Requirements: 13.1, 13.2, 13.3, 13.4, 13.5_

- [ ] 7.3 Run release build and create commit
  - Execute `brazil-build release` to verify build succeeds
  - Execute `brazil-build test` to verify all unit tests pass
  - Execute `brazil-build test --cover` to verify 80% minimum code coverage
  - Create git commit with message: `feat: implement API handlers for chat and history endpoints`
  - _Requirements: 15.1, 15.2, 15.3, 15.4, 15.5_

- [ ] 8. Update main Lambda handler to route new endpoints
- [ ] 8.1 Modify handler.py to add routing for /chat and /chat/history
  - Update `src/<YourLambdaPackage>/handler.py`
  - Add path-based routing logic to detect /chat and /chat/history endpoints
  - Initialize DynamoDBChatRepository with CHAT_SESSIONS_TABLE_NAME environment variable
  - Initialize SessionManager with repository instance
  - Route POST /chat requests to chat_handler()
  - Route POST /chat/history requests to history_handler()
  - Maintain existing / endpoint for backward compatibility
  - Add error response formatting for all endpoints
  - _Requirements: 4.1, 4.2, 4.3, 4.4, 4.5, 4.6, 4.7_

- [ ] 8.2 Write unit tests for Lambda handler routing
  - Create or update `tests/test_handler.py` with routing tests
  - Test / endpoint still routes to existing RAG handler
  - Test /chat endpoint routes to chat_handler
  - Test /chat/history endpoint routes to history_handler
  - Test invalid paths return 404 status code
  - Test invalid HTTP methods return 405 status code
  - Mock all handler functions for isolated routing tests
  - _Requirements: 13.1, 13.2, 13.3, 13.4, 13.5_

- [ ] 8.3 Run release build and create commit
  - Execute `brazil-build release` to verify build succeeds
  - Execute `brazil-build test` to verify all unit tests pass
  - Execute `brazil-build test --cover` to verify 80% minimum code coverage
  - Create git commit with message: `feat: update Lambda handler with chat endpoint routing`
  - _Requirements: 15.1, 15.2, 15.3, 15.4, 15.5_

## Phase 4: Conversation Intelligence

- [ ] 9. Implement message intent classifier
- [ ] 9.1 Create classifier module with MessageIntentClassifier class
  - Create new file `src/<YourLambdaPackage>/classifier.py`
  - Implement `__init__` method to accept ChatBedrockConverse LLM instance
  - Create classification prompt template distinguishing CHAT vs QUERY intents
  - Implement `classify()` method to analyze message and return intent
  - Add fallback logic to default to QUERY intent on classification failures
  - Handle LLM response parsing to extract CHAT or QUERY from response content
  - _Requirements: 8.1, 8.2, 8.3, 8.4, 8.5_

- [ ] 9.2 Write unit tests for intent classifier
  - Create `tests/test_classifier.py` with mocked LLM
  - Test classify() returns "CHAT" for conversational messages (greetings, thanks)
  - Test classify() returns "QUERY" for knowledge-based questions
  - Test classify() defaults to "QUERY" on LLM failures
  - Test classify() handles ambiguous messages appropriately
  - Mock ChatBedrockConverse to avoid actual LLM calls
  - _Requirements: 13.1, 13.2, 13.3, 13.4, 13.5_

- [ ] 9.3 Run release build and create commit
  - Execute `brazil-build release` to verify build succeeds
  - Execute `brazil-build test` to verify all unit tests pass
  - Execute `brazil-build test --cover` to verify 80% minimum code coverage
  - Create git commit with message: `feat: implement message intent classifier`
  - _Requirements: 15.1, 15.2, 15.3, 15.4, 15.5_

- [ ] 10. Implement LangChain memory adapter for DynamoDB
- [ ] 10.1 Create memory adapter module with DynamoDBChatMessageHistory class
  - Create new file `src/<YourLambdaPackage>/memory.py`
  - Implement `DynamoDBChatMessageHistory` class extending `BaseChatMessageHistory`
  - Implement `__init__` method with session_id, repository, and window_size parameters
  - Implement `_load_messages()` method to load recent messages from DynamoDB
  - Implement `messages` property to return list of LangChain messages
  - Implement `add_message()` method to append messages and maintain window size
  - Implement `clear()` method to reset message history
  - Convert MessageModel to LangChain HumanMessage and AIMessage formats
  - Add error handling with graceful fallback to empty history on failures
  - _Requirements: 10.1, 10.2, 10.3, 10.4, 10.5_

- [ ] 10.2 Write unit tests for memory adapter
  - Create `tests/test_memory.py` with mocked repository
  - Test _load_messages() loads messages from repository correctly
  - Test messages property returns LangChain message format
  - Test add_message() appends messages to history
  - Test window size enforcement (maintains only last N messages)
  - Test clear() resets message history
  - Test error handling falls back to empty history on repository failures
  - Mock DynamoDBChatRepository to avoid actual database calls
  - _Requirements: 13.1, 13.2, 13.3, 13.4, 13.5_

- [ ] 10.3 Run release build and create commit
  - Execute `brazil-build release` to verify build succeeds
  - Execute `brazil-build test` to verify all unit tests pass
  - Execute `brazil-build test --cover` to verify 80% minimum code coverage
  - Create git commit with message: `feat: implement LangChain memory adapter for DynamoDB`
  - _Requirements: 15.1, 15.2, 15.3, 15.4, 15.5_

- [ ] 11. Implement hybrid conversation chain with intent-based routing
- [ ] 11.1 Create hybrid chain module with HybridConversationChain class
  - Create new file `src/<YourLambdaPackage>/hybrid_chain.py`
  - Implement `__init__` method accepting LLM, classifier, RAG chain, and memory instances
  - Create simple chat prompt template for conversational messages
  - Implement `invoke()` method to process messages through the hybrid chain
  - Add intent classification logic using MessageIntentClassifier
  - Add routing logic: CHAT intent → simple chat chain, QUERY intent → RAG chain
  - Format conversation history from memory for both chain types
  - Return response with intent classification and sources (for QUERY intents)
  - Ensure both chains share the same conversation memory
  - _Requirements: 9.1, 9.2, 9.3, 9.4, 9.5_

- [ ] 11.2 Write unit tests for hybrid chain
  - Create `tests/test_hybrid_chain.py` with mocked components
  - Test invoke() routes CHAT messages to simple chat chain
  - Test invoke() routes QUERY messages to RAG chain
  - Test conversation history is formatted correctly for both chains
  - Test response includes correct intent classification
  - Test response includes sources for QUERY intents
  - Test response has empty sources for CHAT intents
  - Mock LLM, classifier, RAG chain, and memory for isolated testing
  - _Requirements: 13.1, 13.2, 13.3, 13.4, 13.5_

- [ ] 11.3 Run release build and create commit
  - Execute `brazil-build release` to verify build succeeds
  - Execute `brazil-build test` to verify all unit tests pass
  - Execute `brazil-build test --cover` to verify 80% minimum code coverage
  - Create git commit with message: `feat: implement hybrid conversation chain with intent routing`
  - _Requirements: 15.1, 15.2, 15.3, 15.4, 15.5_

- [ ] 12. Integrate hybrid chain with chat handler
- [ ] 12.1 Update chat_handler to use HybridConversationChain
  - Modify `src/<YourLambdaPackage>/handlers.py`
  - Initialize MessageIntentClassifier with LLM instance
  - Initialize DynamoDBChatMessageHistory with session_id and repository
  - Initialize HybridConversationChain with all required components
  - Update chat_handler to invoke hybrid chain instead of direct RAG chain
  - Extract intent and sources from hybrid chain response
  - Pass intent and sources to save_message_pair() method
  - Update response to include intent and sources in bot messages
  - _Requirements: 9.1, 9.2, 9.3, 9.4, 9.5, 11.1, 11.2, 11.3, 11.4, 11.5, 12.1, 12.2, 12.3, 12.4, 12.5_

- [ ] 12.2 Write integration tests for hybrid chain with handlers
  - Update `tests/test_handlers.py` with hybrid chain integration tests
  - Test chat_handler processes CHAT messages without RAG retrieval
  - Test chat_handler processes QUERY messages with RAG retrieval
  - Test bot responses include correct intent classification
  - Test bot responses include sources for QUERY intents
  - Test conversation history is maintained across multiple messages
  - Mock all external dependencies (DynamoDB, Bedrock, Knowledge Base)
  - _Requirements: 13.1, 13.2, 13.3, 13.4, 13.5_

- [ ] 12.3 Run release build and create commit
  - Execute `brazil-build release` to verify build succeeds
  - Execute `brazil-build test` to verify all unit tests pass
  - Execute `brazil-build test --cover` to verify 80% minimum code coverage
  - Create git commit with message: `feat: integrate hybrid chain with chat handler`
  - _Requirements: 15.1, 15.2, 15.3, 15.4, 15.5_

## Phase 5: Final Validation

- [ ] 13. Validate complete implementation with chatbot-feature-validator script
  - Navigate to `mlu-agcod-lab/` directory
  - Execute validator script with --no-fallback flag: `uv run chatbot-feature-validator.py --no-fallback --query "What is AWS Lambda?"`
  - Verify the /chat endpoint responds with valid ChatResponse format
  - Test conversational message: `uv run chatbot-feature-validator.py --no-fallback --query "Hello"`
  - Verify CHAT intent messages work without RAG retrieval
  - Test knowledge-based query: `uv run chatbot-feature-validator.py --no-fallback --query "How do I configure Lambda VPC?"`
  - Verify QUERY intent messages include source documents
  - Test session continuity by sending multiple messages with same session_id
  - Test /chat/history endpoint retrieves complete conversation history
  - Verify all error scenarios return appropriate HTTP status codes
  - Confirm final code coverage meets 80% minimum with `brazil-build test --cover`
  - Create final commit with message: `feat: complete chatbot feature implementation`
  - _Requirements: 16.1, 16.2, 16.3, 16.4, 16.5_
