# Design Document

## Overview

This document describes the technical design for extending the existing RAG (Retrieval-Augmented Generation) service with multi-turn conversational capabilities. The design builds upon the current Lambda-based architecture, adding DynamoDB for conversation persistence, new API endpoints for chat interactions, and a hybrid chain architecture that intelligently routes messages based on intent classification.

### Current System Architecture

The existing system consists of:
- **Lambda Function**: Python 3.12 runtime hosting the RAG service (`handler.py`)
- **API Gateway**: REST API with IAM authentication exposing the `/` endpoint
- **AWS Bedrock Knowledge Base**: Vector store containing AWS Lambda documentation
- **AWS Bedrock Guardrails**: Content filtering for input/output safety
- **LangChain Integration**: Chain architecture with guardrails, retrieval, prompting, and parsing
- **CDK Infrastructure**: TypeScript-based infrastructure-as-code in `serviceStack.ts`

### Design Goals

1. **Backward Compatibility**: Maintain the existing `/` endpoint for single-turn Q&A
2. **Session Persistence**: Store conversation history in DynamoDB for multi-turn interactions
3. **Intent-Based Routing**: Classify messages as conversational (CHAT) or knowledge-based (QUERY)
4. **Efficient Resource Usage**: Avoid unnecessary knowledge base retrieval for simple conversations
5. **Comprehensive Error Handling**: Provide specific error types with appropriate HTTP status codes
6. **High Test Coverage**: Achieve 80%+ code coverage with mock-based unit tests

## Architecture

### High-Level Component Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                         API Gateway                              │
│  ┌──────────┐  ┌──────────────┐  ┌────────────────────┐        │
│  │ POST /   │  │ POST /chat   │  │ POST /chat/history │        │
│  └──────────┘  └──────────────┘  └────────────────────┘        │
└────────┬────────────────┬────────────────────┬──────────────────┘
         │                │                    │
         │                │                    │
┌────────▼────────────────▼────────────────────▼──────────────────┐
│                    Lambda Handler                                │
│  ┌──────────────┐  ┌──────────────┐  ┌────────────────────┐    │
│  │ query_handler│  │ chat_handler │  │ history_handler    │    │
│  └──────────────┘  └──────────────┘  └────────────────────┘    │
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │              Session Manager                              │  │
│  │  - ULID generation                                        │  │
│  │  - Session validation                                     │  │
│  │  - Message orchestration                                  │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │              Hybrid Conversation Chain                    │  │
│  │  ┌────────────────────┐  ┌──────────────────────────┐    │  │
│  │  │ Intent Classifier  │  │  Conversation Memory     │    │  │
│  │  └────────────────────┘  └──────────────────────────┘    │  │
│  │  ┌────────────────────┐  ┌──────────────────────────┐    │  │
│  │  │ Simple Chat Chain  │  │  RAG Retrieval Chain     │    │  │
│  │  └────────────────────┘  └──────────────────────────┘    │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │              DynamoDB Repository                          │  │
│  │  - save_message()                                         │  │
│  │  - get_session_messages()                                 │  │
│  │  - validate_message_length()                              │  │
│  └──────────────────────────────────────────────────────────┘  │
└────────────────────────────┬─────────────────────────────────────┘
                             │
                             │
┌────────────────────────────▼─────────────────────────────────────┐
│                      DynamoDB Table                               │
│  Table: ${serviceName}-ChatSessions                              │
│  PK: session_id (String)                                         │
│  SK: message_id (String)                                         │
│  Attributes: message_type, message, timestamp, intent, sources   │
└──────────────────────────────────────────────────────────────────┘
```

### Request Flow Diagrams

#### Chat Request Flow

```
User Request → API Gateway → Lambda Handler → chat_handler()
                                                    ↓
                                            Validate Request
                                                    ↓
                                            Session Manager
                                                    ↓
                                    ┌───────────────┴───────────────┐
                                    ↓                               ↓
                            New Session?                    Existing Session?
                                    ↓                               ↓
                            Generate ULID                   Load from DynamoDB
                                    ↓                               ↓
                                    └───────────────┬───────────────┘
                                                    ↓
                                        Hybrid Conversation Chain
                                                    ↓
                                            Intent Classifier
                                                    ↓
                                    ┌───────────────┴───────────────┐
                                    ↓                               ↓
                            CHAT Intent                      QUERY Intent
                                    ↓                               ↓
                        Simple Chat Chain                  RAG Retrieval Chain
                                    ↓                               ↓
                                    └───────────────┬───────────────┘
                                                    ↓
                                        Save to DynamoDB
                                                    ↓
                                        Return ChatResponse
```

#### History Request Flow

```
User Request → API Gateway → Lambda Handler → history_handler()
                                                    ↓
                                            Validate Request
                                                    ↓
                                            Session Manager
                                                    ↓
                                        DynamoDB Repository
                                                    ↓
                                    ┌───────────────┴───────────────┐
                                    ↓                               ↓
                            Session Found?                  Session Not Found?
                                    ↓                               ↓
                        Return HistoryResponse          Return 404 Error
```

## Components and Interfaces

### 1. Data Models (Pydantic)

#### ChatRequest Model
```python
from pydantic import BaseModel, Field
from typing import Optional

class ChatRequest(BaseModel):
    """Request model for /chat endpoint"""
    message: str = Field(
        min_length=1,
        max_length=2048,
        description="User message content"
    )
    session_id: Optional[str] = Field(
        default=None,
        pattern=r'^session_[0-9A-HJKMNP-TV-Za-hjkmnp-tv-z]{26}$',
        description="Optional session ID to continue existing conversation"
    )
```

#### MessageModel
```python
from pydantic import BaseModel, Field
from typing import Literal, Optional, List, Dict, Any
from datetime import datetime

class SourceDocument(BaseModel):
    """Source document metadata"""
    source: str = Field(description="Document identifier")
    title: Optional[str] = Field(default=None, description="Document title")
    page: Optional[int] = Field(default=None, description="Page number")

class MessageModel(BaseModel):
    """Message model for conversation history"""
    message_id: str = Field(
        pattern=r'^message_[0-9A-HJKMNP-TV-Za-hjkmnp-tv-z]{26}$',
        description="Unique message identifier"
    )
    message_type: Literal["HUMAN", "BOT"] = Field(
        description="Type of message sender"
    )
    message: str = Field(
        min_length=1,
        max_length=2048,
        description="Message content"
    )
    timestamp: int = Field(
        description="Unix timestamp of message creation"
    )
    intent: Optional[Literal["CHAT", "QUERY"]] = Field(
        default=None,
        description="Message intent classification (BOT messages only)"
    )
    sources: Optional[List[SourceDocument]] = Field(
        default=None,
        description="Source documents for RAG responses (BOT messages only)"
    )
    
    def to_api_response(self) -> Dict[str, Any]:
        """Convert to API response format"""
        response = {
            "message_id": self.message_id,
            "message_type": self.message_type,
            "message": self.message,
            "timestamp": self.timestamp
        }
        if self.intent:
            response["intent"] = self.intent
        if self.sources:
            response["sources"] = [s.model_dump() for s in self.sources]
        return response
```

#### ChatResponse Model
```python
class ChatResponse(BaseModel):
    """Response model for /chat endpoint"""
    session_id: str = Field(
        pattern=r'^session_[0-9A-HJKMNP-TV-Za-hjkmnp-tv-z]{26}$',
        description="Session identifier"
    )
    messages: List[MessageModel] = Field(
        description="List of messages in the conversation"
    )
```

#### HistoryRequest Model
```python
class HistoryRequest(BaseModel):
    """Request model for /chat/history endpoint"""
    session_id: str = Field(
        pattern=r'^session_[0-9A-HJKMNP-TV-Za-hjkmnp-tv-z]{26}$',
        description="Session identifier to retrieve history for"
    )
```

#### HistoryResponse Model
```python
class HistoryResponse(BaseModel):
    """Response model for /chat/history endpoint"""
    session_id: str = Field(
        pattern=r'^session_[0-9A-HJKMNP-TV-Za-hjkmnp-tv-z]{26}$',
        description="Session identifier"
    )
    messages: List[MessageModel] = Field(
        description="List of messages in the session history"
    )
```

### 2. DynamoDB Repository

```python
import boto3
from typing import List, Optional
from datetime import datetime
import time

class DynamoDBChatRepository:
    """Repository for managing chat messages in DynamoDB"""
    
    def __init__(self, table_name: str, region: str = "us-west-2"):
        """
        Initialize the repository
        
        Args:
            table_name: Name of the DynamoDB table
            region: AWS region
        """
        self.dynamodb = boto3.resource('dynamodb', region_name=region)
        self.table = self.dynamodb.Table(table_name)
    
    def save_message(self, message: MessageModel, session_id: str) -> None:
        """
        Save a message to DynamoDB
        
        Args:
            message: Message to save
            session_id: Session identifier
            
        Raises:
            ChatServiceUnavailableError: If DynamoDB operation fails
            ChatMessageTooLongError: If message exceeds 2048 characters
        """
        if len(message.message) > 2048:
            raise ChatMessageTooLongError(
                f"Message length {len(message.message)} exceeds maximum 2048 characters"
            )
        
        try:
            item = {
                'session_id': session_id,
                'message_id': message.message_id,
                'message_type': message.message_type,
                'message': message.message,
                'timestamp': message.timestamp
            }
            
            if message.intent:
                item['intent'] = message.intent
            if message.sources:
                item['sources'] = [s.model_dump() for s in message.sources]
            
            self.table.put_item(Item=item)
        except Exception as e:
            raise ChatServiceUnavailableError(
                f"Failed to save message to DynamoDB: {str(e)}"
            )
    
    def get_session_messages(
        self, 
        session_id: str, 
        limit: Optional[int] = None
    ) -> List[MessageModel]:
        """
        Retrieve messages for a session
        
        Args:
            session_id: Session identifier
            limit: Optional limit on number of messages to retrieve
            
        Returns:
            List of messages sorted by message_id (chronological order)
            
        Raises:
            ChatServiceUnavailableError: If DynamoDB operation fails
        """
        try:
            query_params = {
                'KeyConditionExpression': 'session_id = :sid',
                'ExpressionAttributeValues': {':sid': session_id},
                'ScanIndexForward': True  # Sort by sort key (message_id) ascending
            }
            
            if limit:
                query_params['Limit'] = limit
            
            response = self.table.query(**query_params)
            items = response.get('Items', [])
            
            messages = []
            for item in items:
                message = MessageModel(
                    message_id=item['message_id'],
                    message_type=item['message_type'],
                    message=item['message'],
                    timestamp=item['timestamp'],
                    intent=item.get('intent'),
                    sources=[SourceDocument(**s) for s in item.get('sources', [])]
                )
                messages.append(message)
            
            return messages
        except Exception as e:
            raise ChatServiceUnavailableError(
                f"Failed to retrieve messages from DynamoDB: {str(e)}"
            )
    
    def session_exists(self, session_id: str) -> bool:
        """
        Check if a session exists
        
        Args:
            session_id: Session identifier
            
        Returns:
            True if session exists, False otherwise
        """
        try:
            response = self.table.query(
                KeyConditionExpression='session_id = :sid',
                ExpressionAttributeValues={':sid': session_id},
                Limit=1,
                Select='COUNT'
            )
            return response.get('Count', 0) > 0
        except Exception:
            return False
```

### 3. Session Manager

```python
from ulid import ULID
import time
from typing import Optional, List, Tuple

class SessionManager:
    """Manages chat sessions and message orchestration"""
    
    def __init__(self, repository: DynamoDBChatRepository):
        """
        Initialize the session manager
        
        Args:
            repository: DynamoDB repository instance
        """
        self.repository = repository
    
    def generate_session_id(self) -> str:
        """
        Generate a new session ID using ULID
        
        Returns:
            Session ID in format: session_<ulid>
        """
        ulid = ULID()
        return f"session_{str(ulid).lower()}"
    
    def generate_message_id(self) -> str:
        """
        Generate a new message ID using ULID
        
        Returns:
            Message ID in format: message_<ulid>
        """
        ulid = ULID()
        return f"message_{str(ulid).lower()}"
    
    def validate_session_id(self, session_id: str) -> bool:
        """
        Validate session ID format
        
        Args:
            session_id: Session ID to validate
            
        Returns:
            True if valid, False otherwise
        """
        import re
        pattern = r'^session_[0-9A-HJKMNP-TV-Za-hjkmnp-tv-z]{26}$'
        return bool(re.match(pattern, session_id))
    
    def create_or_get_session(
        self, 
        session_id: Optional[str]
    ) -> Tuple[str, List[MessageModel]]:
        """
        Create a new session or retrieve existing session
        
        Args:
            session_id: Optional existing session ID
            
        Returns:
            Tuple of (session_id, messages)
            
        Raises:
            ChatSessionNotFoundError: If session_id provided but not found
        """
        if session_id:
            if not self.validate_session_id(session_id):
                raise ValueError(f"Invalid session ID format: {session_id}")
            
            if not self.repository.session_exists(session_id):
                raise ChatSessionNotFoundError(
                    f"Session not found: {session_id}"
                )
            
            messages = self.repository.get_session_messages(session_id)
            return session_id, messages
        else:
            new_session_id = self.generate_session_id()
            return new_session_id, []
    
    def save_message_pair(
        self,
        session_id: str,
        user_message: str,
        bot_response: str,
        intent: str,
        sources: Optional[List[SourceDocument]] = None
    ) -> Tuple[MessageModel, MessageModel]:
        """
        Save a user message and bot response pair
        
        Args:
            session_id: Session identifier
            user_message: User's message content
            bot_response: Bot's response content
            intent: Message intent classification
            sources: Optional source documents
            
        Returns:
            Tuple of (user_message_model, bot_message_model)
        """
        timestamp = int(time.time())
        
        user_msg = MessageModel(
            message_id=self.generate_message_id(),
            message_type="HUMAN",
            message=user_message,
            timestamp=timestamp
        )
        
        bot_msg = MessageModel(
            message_id=self.generate_message_id(),
            message_type="BOT",
            message=bot_response,
            timestamp=timestamp,
            intent=intent,
            sources=sources or []
        )
        
        self.repository.save_message(user_msg, session_id)
        self.repository.save_message(bot_msg, session_id)
        
        return user_msg, bot_msg
```

### 4. Message Intent Classifier

```python
from langchain_aws import ChatBedrockConverse
from langchain_core.prompts import PromptTemplate
from typing import Literal

class MessageIntentClassifier:
    """Classifies message intent as CHAT or QUERY"""
    
    def __init__(self, llm: ChatBedrockConverse):
        """
        Initialize the classifier
        
        Args:
            llm: LangChain LLM instance
        """
        self.llm = llm
        self.prompt = PromptTemplate.from_template(
            """Classify the following message as either CHAT or QUERY.

CHAT: Simple conversational messages like greetings, thanks, acknowledgments, or follow-ups that don't require knowledge retrieval.
Examples: "Hello", "Thanks!", "Got it", "Can you explain that differently?"

QUERY: Knowledge-based questions that require retrieving information from documents.
Examples: "What is AWS Lambda?", "How do I configure VPC?", "Tell me about Lambda pricing"

Message: {message}

Respond with only one word: CHAT or QUERY"""
        )
    
    def classify(self, message: str) -> Literal["CHAT", "QUERY"]:
        """
        Classify message intent
        
        Args:
            message: User message to classify
            
        Returns:
            Intent classification: "CHAT" or "QUERY"
        """
        try:
            chain = self.prompt | self.llm
            response = chain.invoke({"message": message})
            
            # Extract content from response
            content = response.content.strip().upper()
            
            if "CHAT" in content:
                return "CHAT"
            elif "QUERY" in content:
                return "QUERY"
            else:
                # Default to QUERY if unclear
                return "QUERY"
        except Exception:
            # On error, default to QUERY to ensure knowledge retrieval
            return "QUERY"
```

### 5. LangChain Memory Adapter

```python
from langchain_core.chat_history import BaseChatMessageHistory
from langchain_core.messages import BaseMessage, HumanMessage, AIMessage
from typing import List

class DynamoDBChatMessageHistory(BaseChatMessageHistory):
    """
    LangChain memory adapter for DynamoDB-backed conversation history
    
    This adapter implements BaseChatMessageHistory to integrate DynamoDB
    storage with LangChain's conversation memory system.
    """
    
    def __init__(
        self, 
        session_id: str, 
        repository: DynamoDBChatRepository,
        window_size: int = 15
    ):
        """
        Initialize the memory adapter
        
        Args:
            session_id: Session identifier
            repository: DynamoDB repository instance
            window_size: Maximum number of messages to keep in memory
        """
        self.session_id = session_id
        self.repository = repository
        self.window_size = window_size
        self._messages: List[BaseMessage] = []
        self._load_messages()
    
    def _load_messages(self) -> None:
        """Load recent messages from DynamoDB"""
        try:
            db_messages = self.repository.get_session_messages(
                self.session_id,
                limit=self.window_size
            )
            
            self._messages = []
            for msg in db_messages:
                if msg.message_type == "HUMAN":
                    self._messages.append(HumanMessage(content=msg.message))
                elif msg.message_type == "BOT":
                    self._messages.append(AIMessage(content=msg.message))
        except Exception:
            # On error, start with empty history
            self._messages = []
    
    @property
    def messages(self) -> List[BaseMessage]:
        """Return the list of messages"""
        return self._messages
    
    def add_message(self, message: BaseMessage) -> None:
        """
        Add a message to the history
        
        Args:
            message: Message to add
        """
        self._messages.append(message)
        
        # Maintain window size
        if len(self._messages) > self.window_size:
            self._messages = self._messages[-self.window_size:]
    
    def clear(self) -> None:
        """Clear the message history"""
        self._messages = []
```

### 6. Hybrid Conversation Chain

```python
from langchain_core.runnables import RunnableConfig
from typing import Dict, Any, Optional

class HybridConversationChain:
    """
    Hybrid chain that routes messages based on intent classification
    
    Routes CHAT messages to simple conversation chain
    Routes QUERY messages to RAG retrieval chain
    """
    
    def __init__(
        self,
        llm: ChatBedrockConverse,
        classifier: MessageIntentClassifier,
        rag_chain: Any,  # The existing RAG chain
        memory: DynamoDBChatMessageHistory
    ):
        """
        Initialize the hybrid chain
        
        Args:
            llm: LangChain LLM instance
            classifier: Intent classifier instance
            rag_chain: Existing RAG retrieval chain
            memory: Conversation memory adapter
        """
        self.llm = llm
        self.classifier = classifier
        self.rag_chain = rag_chain
        self.memory = memory
        
        # Simple chat prompt for conversational messages
        self.chat_prompt = PromptTemplate.from_template(
            """You are a friendly AWS assistant. Respond naturally to the user's message.

Conversation history:
{history}

User: {message}
Assistant:"""
        )
    
    def invoke(
        self,
        message: str,
        config: Optional[RunnableConfig] = None
    ) -> Dict[str, Any]:
        """
        Process a message through the hybrid chain
        
        Args:
            message: User message
            config: Optional runnable configuration
            
        Returns:
            Dict with 'response', 'intent', and 'sources' keys
        """
        # Classify message intent
        intent = self.classifier.classify(message)
        
        # Format conversation history
        history_text = "\n".join([
            f"{'User' if isinstance(msg, HumanMessage) else 'Assistant'}: {msg.content}"
            for msg in self.memory.messages
        ])
        
        # Route based on intent
        if intent == "CHAT":
            # Use simple chat chain
            chain = self.chat_prompt | self.llm
            response = chain.invoke({
                "history": history_text,
                "message": message
            })
            
            return {
                "response": response.content,
                "intent": "CHAT",
                "sources": []
            }
        else:
            # Use RAG retrieval chain
            rag_response = self.rag_chain.invoke({
                "question": message,
                "history": history_text
            }, config=config)
            
            return {
                "response": rag_response.get("answer", ""),
                "intent": "QUERY",
                "sources": rag_response.get("sources", [])
            }
```

### 7. Custom Exception Classes

```python
class ChatException(Exception):
    """Base exception for chat service errors"""
    def __init__(self, message: str, status_code: int = 500):
        self.message = message
        self.status_code = status_code
        super().__init__(self.message)

class ChatSessionNotFoundError(ChatException):
    """Raised when a session is not found"""
    def __init__(self, message: str):
        super().__init__(message, status_code=404)

class ChatMessageTooLongError(ChatException):
    """Raised when a message exceeds maximum length"""
    def __init__(self, message: str):
        super().__init__(message, status_code=400)

class ChatServiceUnavailableError(ChatException):
    """Raised when DynamoDB or other services are unavailable"""
    def __init__(self, message: str):
        super().__init__(message, status_code=503)

class GuardrailInterventionError(ChatException):
    """Raised when content is blocked by guardrails"""
    def __init__(self, message: str):
        super().__init__(message, status_code=400)

class ChatTokenLimitExceededError(ChatException):
    """Raised when token limit is exceeded"""
    def __init__(self, message: str):
        super().__init__(message, status_code=400)
```

### 8. API Handler Functions

```python
import json
from typing import Dict, Any

def chat_handler(
    event: Dict[str, Any],
    session_manager: SessionManager,
    hybrid_chain: HybridConversationChain
) -> Dict[str, Any]:
    """
    Handle /chat endpoint requests
    
    Args:
        event: API Gateway event
        session_manager: Session manager instance
        hybrid_chain: Hybrid conversation chain instance
        
    Returns:
        API Gateway response
    """
    try:
        # Parse and validate request
        body = json.loads(event.get("body", "{}"))
        request = ChatRequest(**body)
        
        # Create or get session
        session_id, messages = session_manager.create_or_get_session(
            request.session_id
        )
        
        # Process message through hybrid chain
        result = hybrid_chain.invoke(request.message)
        
        # Save message pair
        user_msg, bot_msg = session_manager.save_message_pair(
            session_id=session_id,
            user_message=request.message,
            bot_response=result["response"],
            intent=result["intent"],
            sources=result.get("sources")
        )
        
        # Build response
        response = ChatResponse(
            session_id=session_id,
            messages=[user_msg, bot_msg]
        )
        
        return {
            "statusCode": 200,
            "body": json.dumps(response.model_dump()),
            "headers": {"Content-Type": "application/json"}
        }
        
    except ChatException as e:
        return {
            "statusCode": e.status_code,
            "body": json.dumps({"error": type(e).__name__, "message": e.message}),
            "headers": {"Content-Type": "application/json"}
        }
    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({"error": "InternalServerError", "message": str(e)}),
            "headers": {"Content-Type": "application/json"}
        }

def history_handler(
    event: Dict[str, Any],
    session_manager: SessionManager
) -> Dict[str, Any]:
    """
    Handle /chat/history endpoint requests
    
    Args:
        event: API Gateway event
        session_manager: Session manager instance
        
    Returns:
        API Gateway response
    """
    try:
        # Parse and validate request
        body = json.loads(event.get("body", "{}"))
        request = HistoryRequest(**body)
        
        # Get session messages
        _, messages = session_manager.create_or_get_session(request.session_id)
        
        # Build response
        response = HistoryResponse(
            session_id=request.session_id,
            messages=messages
        )
        
        return {
            "statusCode": 200,
            "body": json.dumps(response.model_dump()),
            "headers": {"Content-Type": "application/json"}
        }
        
    except ChatSessionNotFoundError as e:
        return {
            "statusCode": 404,
            "body": json.dumps({"error": "SessionNotFound", "message": e.message}),
            "headers": {"Content-Type": "application/json"}
        }
    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({"error": "InternalServerError", "message": str(e)}),
            "headers": {"Content-Type": "application/json"}
        }
```

## Data Models

### DynamoDB Table Schema

```
Table Name: ${serviceName}-ChatSessions
Partition Key: session_id (String)
Sort Key: message_id (String)

Attributes:
- session_id: String (PK) - Format: session_<ulid>
- message_id: String (SK) - Format: message_<ulid>
- message_type: String - "HUMAN" or "BOT"
- message: String - Message content (max 2048 chars)
- timestamp: Number - Unix timestamp
- intent: String (optional) - "CHAT" or "QUERY" (BOT messages only)
- sources: List (optional) - Source documents (BOT messages only)
  - source: String - Document identifier
  - title: String - Document title
  - page: Number - Page number
```

### API Request/Response Formats

See "Components and Interfaces" section above for detailed Pydantic models.

## Error Handling

### Error Response Format

All error responses follow this structure:

```json
{
  "error": "ErrorTypeName",
  "message": "Human-readable error description"
}
```

### HTTP Status Code Mapping

| Exception | Status Code | Description |
|-----------|-------------|-------------|
| ChatSessionNotFoundError | 404 | Session ID not found in database |
| ChatMessageTooLongError | 400 | Message exceeds 2048 character limit |
| GuardrailInterventionError | 400 | Content blocked by Bedrock guardrails |
| ChatTokenLimitExceededError | 400 | Conversation token limit exceeded |
| ChatServiceUnavailableError | 503 | DynamoDB or other AWS service unavailable |
| ValidationError (Pydantic) | 400 | Request validation failed |
| Generic Exception | 500 | Unexpected internal server error |

### Error Handling Strategy

1. **Input Validation**: Use Pydantic models to validate all requests at the API boundary
2. **Service Errors**: Wrap AWS service calls in try-except blocks and raise appropriate custom exceptions
3. **Graceful Degradation**: On memory load failures, start with empty history rather than failing
4. **Intent Classification Fallback**: Default to QUERY intent if classification fails
5. **Logging**: Log all errors with context for debugging in CloudWatch

## Testing Strategy

### Unit Testing Approach

1. **Mock External Dependencies**:
   - Mock boto3 DynamoDB client for repository tests
   - Mock Bedrock client for LLM and RAG chain tests
   - Mock environment variables for configuration tests

2. **Test Coverage Requirements**:
   - Minimum 80% code coverage across all modules
   - 100% coverage for critical paths (error handling, validation)
   - Test both positive and negative scenarios

3. **Test Organization**:
   ```
   tests/
   ├── test_models.py          # Pydantic model validation tests
   ├── test_repository.py      # DynamoDB repository tests
   ├── test_session_manager.py # Session management tests
   ├── test_classifier.py      # Intent classification tests
   ├── test_memory.py          # Memory adapter tests
   ├── test_hybrid_chain.py    # Hybrid chain tests
   ├── test_handlers.py        # API handler tests
   └── test_exceptions.py      # Exception handling tests
   ```

4. **Key Test Scenarios**:
   - Valid and invalid request formats
   - Session creation and continuation
   - Message length validation
   - Intent classification accuracy
   - Error handling for each exception type
   - DynamoDB connection failures
   - Memory window management
   - ULID generation and validation

### Integration Testing

Use the `chatbot-feature-validator.py` script for end-to-end testing:

1. **Setup Validation**: Test existing RAG service in fallback mode
2. **Chat Endpoint Testing**: Test /chat endpoint with various message types
3. **Session Continuity**: Test multi-turn conversations with session IDs
4. **History Retrieval**: Test /chat/history endpoint
5. **Error Scenarios**: Test invalid inputs and error responses

## Implementation Guidance

### Phase 1: System Documentation and Setup (Tasks 1-2)

**Task 1: System Architecture Documentation**
- Document existing Lambda handler structure and routing
- Document CDK infrastructure components
- Document LangChain integration and chain architecture
- Document current error handling patterns
- Create architecture diagrams for reference

**Task 2: Environment Setup and Validation**
- Configure .env file with CHAT_ENDPOINT
- Execute validator script in fallback mode
- Verify RAG service responds correctly
- Confirm AWS credentials and permissions
- Document baseline functionality

### Phase 2: Infrastructure and Data Layer (Tasks 3-7)

**Task 3: CDK Infrastructure Updates**
- Add DynamoDB table definition to serviceStack.ts
- Configure table permissions for Lambda
- Add environment variable for table name
- Deploy and verify table creation

**Task 4: Data Models**
- Implement Pydantic models (ChatRequest, MessageModel, etc.)
- Add validation rules and patterns
- Write unit tests for model validation
- Run brazil-build release and commit

**Task 5: DynamoDB Repository**
- Implement DynamoDBChatRepository class
- Add save_message and get_session_messages methods
- Implement error handling with custom exceptions
- Write unit tests with mocked DynamoDB client
- Run brazil-build release and commit

**Task 6: Session Manager**
- Implement SessionManager class
- Add ULID generation for session and message IDs
- Implement session validation logic
- Write unit tests for session operations
- Run brazil-build release and commit

**Task 7: Custom Exception Classes**
- Implement all custom exception classes
- Add HTTP status code mapping
- Write unit tests for exception behavior
- Run brazil-build release and commit

### Phase 3: API Layer (Tasks 8-9)

**Task 8: API Handler Functions**
- Implement chat_handler function
- Implement history_handler function
- Add request validation and error handling
- Update main Lambda handler routing
- Write unit tests with mocked dependencies
- Run brazil-build release and commit

**Task 9: Lambda Handler Integration**
- Update handler.py to route /chat and /chat/history
- Add error response formatting
- Test endpoint routing
- Write integration tests
- Run brazil-build release and commit

### Phase 4: Conversation Intelligence (Tasks 10-12)

**Task 10: Message Intent Classifier**
- Implement MessageIntentClassifier class
- Create classification prompt template
- Add fallback logic for classification failures
- Write unit tests with mocked LLM
- Run brazil-build release and commit

**Task 11: LangChain Memory Adapter**
- Implement DynamoDBChatMessageHistory class
- Add message loading and window management
- Implement BaseChatMessageHistory interface
- Write unit tests with mocked repository
- Run brazil-build release and commit

**Task 12: Hybrid Conversation Chain**
- Implement HybridConversationChain class
- Add intent-based routing logic
- Integrate with existing RAG chain
- Write unit tests with mocked components
- Run brazil-build release and commit

### Phase 5: Final Integration and Validation (Task 13)

**Task 13: End-to-End Validation**
- Execute validator script with --no-fallback flag
- Test chat endpoint with various message types
- Test session continuity across multiple messages
- Test history retrieval endpoint
- Verify error handling scenarios
- Confirm 80% code coverage
- Create final commit

### Build Commands Reference

```bash
# Fetch dependencies and build
brazil-build

# Run unit tests
brazil-build test

# Check code coverage (minimum 80%)
brazil-build test --cover

# Run code formatting
brazil-build format

# Clean build artifacts
brazil-build clean

# Full release build (includes all checks)
brazil-build release
```

### Git Commit Strategy

After completing each implementation task:

1. Run `brazil-build release` to verify build succeeds
2. Run `brazil-build test` to verify all tests pass
3. Run `brazil-build test --cover` to verify 80% coverage
4. Create commit with format: `feat: <task-description>`
   - Example: `feat: implement DynamoDB repository with error handling`
5. Include task reference in commit message body

## CDK Infrastructure Changes

### DynamoDB Table Definition

Add to `serviceStack.ts`:

```typescript
import * as dynamodb from 'aws-cdk-lib/aws-dynamodb';

// In the ServiceStack constructor:

// Create DynamoDB table for chat sessions
const chatSessionsTable = new dynamodb.Table(this, 'ChatSessionsTable', {
  tableName: `${serviceName}-ChatSessions`,
  partitionKey: {
    name: 'session_id',
    type: dynamodb.AttributeType.STRING
  },
  sortKey: {
    name: 'message_id',
    type: dynamodb.AttributeType.STRING
  },
  billingMode: dynamodb.BillingMode.PAY_PER_REQUEST,
  removalPolicy: cdk.RemovalPolicy.DESTROY, // For development
  pointInTimeRecovery: true
});

// Grant Lambda read/write permissions
chatSessionsTable.grantReadWriteData(lambdaFunction);

// Add table name to Lambda environment variables
lambdaFunction.addEnvironment('CHAT_SESSIONS_TABLE_NAME', chatSessionsTable.tableName);
```

### Environment Variables

The Lambda function will have access to:
- `CHAT_SESSIONS_TABLE_NAME`: DynamoDB table name
- `KNOWLEDGE_BASE_ID`: Existing Bedrock Knowledge Base ID
- `GUARDRAIL_ID`: Existing Bedrock Guardrail ID
- `GUARDRAIL_VERSION`: Existing Bedrock Guardrail version

## Security Considerations

1. **IAM Authentication**: All API endpoints use IAM authentication via API Gateway
2. **Input Validation**: Pydantic models validate all inputs at the API boundary
3. **Content Filtering**: Bedrock Guardrails filter both input and output content
4. **Message Length Limits**: 2048 character maximum prevents abuse
5. **DynamoDB Permissions**: Lambda has least-privilege access (read/write only)
6. **Error Messages**: Generic error messages prevent information leakage

## Performance Considerations

1. **Conversation Window**: Limit to 15 messages to control token usage
2. **Intent Classification**: Avoid unnecessary knowledge base queries for simple chat
3. **DynamoDB Queries**: Use partition key queries for efficient retrieval
4. **ULID Sorting**: Lexicographic sorting enables efficient chronological ordering
5. **Memory Caching**: Load messages once per request, cache in memory adapter

## Monitoring and Observability

1. **CloudWatch Logs**: All Lambda invocations logged with request/response details
2. **Error Tracking**: Custom exceptions logged with full context
3. **Metrics**: Track API endpoint usage, error rates, and latency
4. **DynamoDB Metrics**: Monitor read/write capacity and throttling
5. **Bedrock Metrics**: Track LLM invocations and token usage

## Future Enhancements

1. **Session Expiration**: Add TTL to DynamoDB for automatic cleanup
2. **Rate Limiting**: Implement per-user rate limits
3. **Conversation Summarization**: Compress long conversations
4. **Multi-Modal Support**: Add support for images and documents
5. **Streaming Responses**: Implement server-sent events for real-time responses
6. **Analytics**: Track conversation patterns and user engagement
