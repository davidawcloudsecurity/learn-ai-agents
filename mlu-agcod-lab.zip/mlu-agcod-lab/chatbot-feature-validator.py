#!/usr/bin/env -S uv run
# /// script
# requires-python = ">=3.13"
# dependencies = [
#     "boto3",
#     "click",
#     "prompt-toolkit",
#     "python-dotenv",
#     "requests",
#     "rich",
#     "typing-extensions",
#     "ulid-py",
# ]
# ///

# add dependencies using UV like `uv add --script example.py boto3 click`
"""
Completely standalone CLI tool for interacting with the chat service.

This script provides a command-line interface for interacting with the chat service,
allowing users to have conversations with the RAG system in an interactive manner.
This version is completely standalone and doesn't import any package code.
"""

import json
import os
import sys
import time
import urllib.parse
from typing import Optional, Dict, List, Any

import boto3
import click
import requests
from botocore.auth import SigV4Auth
from botocore.awsrequest import AWSRequest
from dotenv import load_dotenv
from prompt_toolkit import PromptSession
from prompt_toolkit.history import FileHistory
from prompt_toolkit.auto_suggest import AutoSuggestFromHistory
from prompt_toolkit.styles import Style
from rich.console import Console
from rich.panel import Panel
from rich.markdown import Markdown
from rich.theme import Theme

# Import validation utilities (these would normally be imported from the service package)
# For the standalone validator, we'll include simplified versions inline
from dataclasses import dataclass
import re

# Define Rich theme and console
rich_theme = Theme({
    "info": "cyan",
    "warning": "yellow",
    "error": "bold red",
    "user": "green",
    "bot": "blue",
    "system": "magenta",
})
console = Console(theme=rich_theme)

# Define prompt styles
prompt_style = Style.from_dict({
    "prompt": "green bold",
})


@dataclass
class ValidationResult:
    """Result of response validation with detailed feedback."""
    is_valid: bool
    issues: List[str]
    suggestions: List[str]
    error_type: Optional[str] = None


class ResponseValidator:
    """Validates service responses and provides helpful error messages."""
    
    @staticmethod
    def validate_chat_response(response_data: Dict[str, Any]) -> ValidationResult:
        """Validate chat response format and content."""
        issues = []
        suggestions = []
        error_type = None
        
        # Check if response is a dictionary
        if not isinstance(response_data, dict):
            issues.append(f"Expected response to be a JSON object, got {type(response_data).__name__}")
            suggestions.append("Ensure the service returns a valid JSON response")
            return ValidationResult(False, issues, suggestions, "INVALID_RESPONSE_TYPE")
        
        # Check for error response format
        if "error" in response_data:
            return ResponseValidator._validate_error_response(response_data)
        
        # Check for required fields
        required_fields = ["session_id", "messages"]
        missing_fields = [field for field in required_fields if field not in response_data]
        
        if missing_fields:
            issues.append(f"Missing required fields: {', '.join(missing_fields)}")
            suggestions.extend([
                "Ensure the service returns both 'session_id' and 'messages' fields",
                "Check if the handler is properly returning ChatResponse.model_dump()"
            ])
            error_type = "MISSING_REQUIRED_FIELDS"
        
        # Validate session_id format
        session_id = response_data.get("session_id")
        if session_id:
            session_validation = ResponseValidator._validate_session_id(session_id)
            if not session_validation.is_valid:
                issues.extend(session_validation.issues)
                suggestions.extend(session_validation.suggestions)
                error_type = session_validation.error_type
        
        # Validate messages array
        messages = response_data.get("messages")
        if messages is not None:
            messages_validation = ResponseValidator._validate_messages_array(messages)
            if not messages_validation.is_valid:
                issues.extend(messages_validation.issues)
                suggestions.extend(messages_validation.suggestions)
                error_type = messages_validation.error_type or error_type
        
        is_valid = len(issues) == 0
        return ValidationResult(is_valid, issues, suggestions, error_type)
    
    @staticmethod
    def _validate_error_response(response_data: Dict[str, Any]) -> ValidationResult:
        """Validate error response format and provide specific guidance."""
        issues = []
        suggestions = []
        
        error_field = response_data.get("error")
        message_field = response_data.get("message")
        
        # Check for common error patterns
        if isinstance(error_field, str) or "error" in str(response_data).lower():
            response_str = str(response_data)
            
            # Check for specific error types with targeted suggestions
            if "Internal server error" in response_str or "internal server error" in response_str.lower():
                issues.append("Server encountered an internal error")
                suggestions.extend([
                    "Check CloudWatch logs for detailed error information",
                    "Verify all required environment variables are set (KNOWLEDGE_BASE_ID, GUARDRAIL_ID, etc.)",
                    "Ensure the Knowledge Base ID has the correct format (36 characters minimum)",
                    "Verify AWS permissions for Bedrock and Knowledge Base access"
                ])
                return ValidationResult(False, issues, suggestions, "INTERNAL_SERVER_ERROR")
            
            elif "Invalid length for parameter IndexId" in response_str:
                issues.append("Knowledge Base configuration error - IndexId parameter is invalid")
                suggestions.extend([
                    "Check the KNOWLEDGE_BASE_ID environment variable format",
                    "Ensure IndexId is at least 36 characters long",
                    "Verify the Knowledge Base exists and is properly configured",
                    "Check if the Knowledge Base ID in the environment matches the actual resource"
                ])
                return ValidationResult(False, issues, suggestions, "INVALID_KNOWLEDGE_BASE_ID")
            
            elif "guardrail" in response_str.lower():
                issues.append("Content was blocked by Guardrail")
                suggestions.extend([
                    "Review the input message for potentially problematic content",
                    "Check Guardrail configuration and rules",
                    "Consider adjusting the message to comply with content policies"
                ])
                return ValidationResult(False, issues, suggestions, "GUARDRAIL_INTERVENTION")
        
        # Generic error response validation
        if not error_field:
            issues.append("Error response missing 'error' field")
            suggestions.append("Ensure error responses include an error type identifier")
        
        if not message_field:
            issues.append("Error response missing 'message' field") 
            suggestions.append("Ensure error responses include a descriptive message")
        
        return ValidationResult(False, issues, suggestions, "INVALID_ERROR_RESPONSE")
    
    @staticmethod
    def _validate_session_id(session_id: Any) -> ValidationResult:
        """Validate session ID format."""
        issues = []
        suggestions = []
        
        if not isinstance(session_id, str):
            issues.append(f"Session ID must be a string, got {type(session_id).__name__}")
            suggestions.append("Ensure session ID is generated as a string")
            return ValidationResult(False, issues, suggestions, "INVALID_SESSION_ID_TYPE")
        
        # Check ULID format: session_<26-char-base32> (case insensitive)
        pattern = r'^session_[0-9A-HJKMNP-TV-Za-hjkmnp-tv-z]{26}$'
        if not re.match(pattern, session_id):
            issues.append(f"Invalid session ID format: {session_id}")
            suggestions.extend([
                "Session ID should follow format: session_<26-character-ULID>",
                "Verify the session manager is generating proper ULID format",
                "Check that session ID generation uses valid Base32 characters"
            ])
            return ValidationResult(False, issues, suggestions, "INVALID_SESSION_ID_FORMAT")
        
        return ValidationResult(True, [], [])
    
    @staticmethod
    def _validate_messages_array(messages: Any) -> ValidationResult:
        """Validate messages array format and content."""
        issues = []
        suggestions = []
        
        if not isinstance(messages, list):
            issues.append(f"Messages must be an array, got {type(messages).__name__}")
            suggestions.append("Ensure messages are returned as a JSON array")
            return ValidationResult(False, issues, suggestions, "INVALID_MESSAGES_TYPE")
        
        if len(messages) == 0:
            issues.append("Messages array is empty")
            suggestions.extend([
                "Ensure at least one message is included in the response",
                "Check if message saving to repository is working correctly"
            ])
            return ValidationResult(False, issues, suggestions, "EMPTY_MESSAGES_ARRAY")
        
        # Validate each message
        for i, message in enumerate(messages):
            message_validation = ResponseValidator._validate_single_message(message, i)
            if not message_validation.is_valid:
                issues.extend(message_validation.issues)
                suggestions.extend(message_validation.suggestions)
        
        return ValidationResult(len(issues) == 0, issues, suggestions)
    
    @staticmethod
    def _validate_single_message(message: Any, index: int) -> ValidationResult:
        """Validate individual message format and detect field mapping issues."""
        issues = []
        suggestions = []
        
        if not isinstance(message, dict):
            issues.append(f"Message {index} must be an object, got {type(message).__name__}")
            suggestions.append(f"Ensure message {index} is a JSON object")
            return ValidationResult(False, issues, suggestions, "INVALID_MESSAGE_TYPE")
        
        # Check for the correct API response fields (based on the specification)
        expected_api_fields = ["message_id", "message_type", "message", "timestamp"]
        missing_api_fields = [field for field in expected_api_fields if field not in message]
        
        # Check if incorrect fields are present (role/content instead of message_type/message)
        incorrect_fields = {"role": message.get("role"), "content": message.get("content")}
        has_incorrect_fields = any(value is not None for value in incorrect_fields.values())
        
        # Detect field mapping issues - using wrong field names
        if missing_api_fields and has_incorrect_fields:
            issues.append(f"Message {index} contains incorrect field names")
            issues.append(f"Found incorrect fields: {[k for k, v in incorrect_fields.items() if v is not None]}")
            issues.append(f"Missing correct API fields: {missing_api_fields}")
            suggestions.extend([
                f"Field naming issue detected - using wrong field names",
                "The API specification expects 'message_type' field, not 'role'",
                "The API specification expects 'message' field, not 'content'", 
                "Check MessageModel.to_api_response() method returns correct field names",
                "Verify the service is following the correct API specification"
            ])
            return ValidationResult(False, issues, suggestions, "INCORRECT_FIELD_NAMES")
        
        # Check for completely missing fields
        if missing_api_fields and not has_incorrect_fields:
            # Check if message is completely empty or has wrong structure
            available_fields = list(message.keys())
            if not available_fields:
                issues.append(f"Message {index} is empty - no fields found")
                suggestions.extend([
                    "Check if messages are being properly saved to the database",
                    "Verify repository.save_message() is working correctly",
                    "Check if MessageModel creation is successful"
                ])
            else:
                issues.append(f"Message {index} missing required API fields: {missing_api_fields}")
                issues.append(f"Available fields: {available_fields}")
                suggestions.extend([
                    f"Message {index} has unexpected field structure",
                    "Verify MessageModel.to_api_response() is being called",
                    "Check if the correct message format is being returned"
                ])
            return ValidationResult(False, issues, suggestions, "MISSING_REQUIRED_FIELDS")
        
        # Validate message_type field (if present)
        message_type = message.get("message_type")
        if message_type is not None:
            if message_type not in ["HUMAN", "BOT"]:
                issues.append(f"Message {index} has invalid message_type: '{message_type}'")
                suggestions.extend([
                    f"message_type must be either 'HUMAN' or 'BOT', got '{message_type}'",
                    "Check MessageModel creation and database storage logic"
                ])
        
        # Validate message field (if present)
        message_content = message.get("message")
        if message_content is not None:
            if not isinstance(message_content, str):
                issues.append(f"Message {index} message must be a string, got {type(message_content).__name__}")
                suggestions.append(f"Ensure message {index} message is properly serialized as string")
            elif not message_content.strip():
                issues.append(f"Message {index} has empty message content")
                suggestions.extend([
                    "Empty message content detected - this may appear as blank in the UI",
                    "Check if the original message was properly stored",
                    "Verify conversation chain is returning valid responses"
                ])
        
        # Special detection for the "empty messages" issue
        if not message_content or not message_content.strip():
            if message_type:
                issues.append(f"Message {index} has message_type '{message_type}' but empty/missing message content")
                suggestions.extend([
                    "This creates empty message display in the UI",
                    "The message has metadata but no actual content to display",
                    "Check the conversation chain response generation"
                ])
        
        # Validate timestamp format (if present)
        timestamp = message.get("timestamp")
        if timestamp:
            try:
                # Basic ISO format validation
                if isinstance(timestamp, str):
                    if not re.match(r'^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}', timestamp):
                        issues.append(f"Message {index} has invalid timestamp format: {timestamp}")
                        suggestions.append(f"Ensure message {index} timestamp follows ISO 8601 format")
                elif not isinstance(timestamp, (int, float)):
                    issues.append(f"Message {index} timestamp must be string or number, got {type(timestamp).__name__}")
            except (TypeError, ValueError):
                issues.append(f"Message {index} timestamp validation failed")
                suggestions.append(f"Ensure message {index} timestamp is properly formatted")
        
        return ValidationResult(len(issues) == 0, issues, suggestions)


def generate_user_friendly_error_message(validation_result: ValidationResult) -> str:
    """Generate a user-friendly error message with actionable suggestions."""
    error_lines = ["❌ Service Response Validation Failed"]
    error_lines.append("=" * 50)
    
    # Add issues
    if validation_result.issues:
        error_lines.append("\n🔍 Issues Found:")
        for i, issue in enumerate(validation_result.issues, 1):
            error_lines.append(f"  {i}. {issue}")
    
    # Add suggestions
    if validation_result.suggestions:
        error_lines.append("\n💡 Suggested Fixes:")
        for i, suggestion in enumerate(validation_result.suggestions, 1):
            error_lines.append(f"  {i}. {suggestion}")
    
    # Add error type for debugging
    if validation_result.error_type:
        error_lines.append(f"\n🏷️  Error Type: {validation_result.error_type}")
    
    error_lines.append("\n" + "=" * 50)
    error_lines.append("For more help, check the service logs in CloudWatch.")
    
    return "\n".join(error_lines)


class ChatClient:
    """Client for interacting with the chat service."""

    def __init__(self, endpoint: str, profile: Optional[str] = None, region: Optional[str] = None):
        """Initialize the chat client.
        
        Args:
            endpoint: The URL of the chat service endpoint.
            profile: The AWS profile to use for authentication.
            region: The AWS region to use for authentication.
        """
        self.endpoint = endpoint.rstrip("/")
        self.session_id: Optional[str] = None
        self.messages: List[Dict[str, Any]] = []
        self.profile = profile
        self.region = region
        
        # Initialize AWS session
        self.aws_session = boto3.Session(profile_name=profile, region_name=region)
        console.print(f"[info]Using AWS profile: {profile or 'default'} and region: {region or self.aws_session.region_name or 'us-west-2'}[/info]")
    
    def fetch_history(self, session_id: str) -> Dict[str, Any]:
        """Fetch chat history using the /chat/history endpoint.
        
        Args:
            session_id: The ID of the session to fetch history for.
            
        Returns:
            Dict[str, Any]: The response from the chat service.
        """
        url = f"{self.endpoint}/chat/history"
        payload = {"session_id": session_id}
        
        try:
            # Parse the URL to get the host
            parsed_url = urllib.parse.urlparse(url)
            host = parsed_url.netloc
            
            # Get credentials from the session
            credentials = self.aws_session.get_credentials()
            if credentials is None:
                raise ValueError("No AWS credentials found. Please check your AWS configuration.")
                
            region = self.aws_session.region_name or "us-west-2"
            
            # Create a request to sign
            request = AWSRequest(
                method="POST",
                url=url,
                data=json.dumps(payload),
                headers={
                    "Host": host,
                    "Content-Type": "application/json",
                }
            )
            
            # Sign the request
            SigV4Auth(credentials, "execute-api", region).add_auth(request)
            
            # Convert to a requests request
            signed_headers = dict(request.headers)
            
            # Make the request
            response = requests.post(
                url,
                json=payload,
                headers=signed_headers
            )
            
            response.raise_for_status()
            return response.json()
        except Exception as e:
            console.print(f"[error]Error fetching history: {str(e)}[/error]")
            if hasattr(e, "response") and e.response is not None:
                try:
                    error_data = e.response.json()
                    console.print(f"[error]Server response: {json.dumps(error_data, indent=2)}[/error]")
                except Exception:
                    console.print(f"[error]Server response: {e.response.text}[/error]")
            return {"error": str(e)}

    def load_session(self, session_id: str) -> bool:
        """Load an existing chat session.
        
        Args:
            session_id: The ID of the session to load.
            
        Returns:
            bool: True if the session was loaded successfully, False otherwise.
        """
        self.session_id = session_id
        console.print(f"[info]Loading session {session_id}...[/info]")
        
        try:
            # Use the new /chat/history endpoint to fetch session history
            response = self.fetch_history(session_id)
            if "error" in response:
                console.print(f"[error]Failed to load session: {response.get('error')}[/error]")
                self.session_id = None
                return False
            
            # Update messages from the history response
            self.messages = response.get("messages", [])
            
            # Display the conversation history
            console.print("[info]Session loaded successfully.[/info]")
            console.print("[bold]Conversation history:[/bold]")
            display_conversation(self.messages)
            return True
        except Exception as e:
            console.print(f"[error]Failed to load session: {str(e)}[/error]")
            self.session_id = None
            return False
    
    def send_message(self, message: str, fetch_only: bool = False) -> Dict[str, Any]:
        """Send a message to the chat service.
        
        Args:
            message: The message to send.
            fetch_only: If True, only fetch the session without sending a new message.
            
        Returns:
            Dict[str, Any]: The response from the chat service.
        """
        url = f"{self.endpoint}/chat"
        payload = {}
        
        # Only include the message if we're not just fetching the session
        if not fetch_only and message.strip():
            payload["message"] = message
        
        if self.session_id:
            payload["session_id"] = self.session_id
        
        # If we're just fetching and there's no message, we need to include a dummy message
        # to avoid validation errors, but we'll add a special flag to indicate this is a fetch
        if fetch_only and not message.strip():
            payload["message"] = " "  # Space to pass validation
            payload["fetch_only"] = True  # This will be ignored by the server but helps with debugging
        
        try:
            # Parse the URL to get the host
            parsed_url = urllib.parse.urlparse(url)
            host = parsed_url.netloc
            
            # Get credentials from the session
            credentials = self.aws_session.get_credentials()
            if credentials is None:
                raise ValueError("No AWS credentials found. Please check your AWS configuration.")
                
            region = self.aws_session.region_name or "us-west-2"  # Default to us-west-2 if not set
            
            # Create a request to sign
            request = AWSRequest(
                method="POST",
                url=url,
                data=json.dumps(payload),
                headers={
                    "Host": host,
                    "Content-Type": "application/json",
                }
            )
            
            # Sign the request
            SigV4Auth(credentials, "execute-api", region).add_auth(request)
            
            # Convert to a requests request
            signed_headers = dict(request.headers)
            
            # Make the request
            response = requests.post(
                url,
                json=payload,
                headers=signed_headers
            )
            
            # Check for server errors (5xx)
            if 500 <= response.status_code < 600:
                error_data = {}
                try:
                    error_data = response.json()
                except Exception:
                    error_data = {"error": response.text}
                
                # Check for specific error messages
                error_message = error_data.get("error", "")
                if "Internal server error" in error_message:
                    console.print("[error]The server encountered an internal error.[/error]")
                    console.print("[info]This might be due to missing or invalid environment variables on the server.[/info]")
                    console.print("[info]The error in CloudTrail logs shows: 'Invalid length for parameter IndexId, value: 10, valid min length: 36'[/info]")
                    
                    # Return a friendly error message
                    return {
                        "error": "Server configuration error",
                        "message": "The chat service is not properly configured."
                    }
            
            # For non-5xx errors or after handling specific errors, continue with normal flow
            response.raise_for_status()
            data = response.json()
            
            # Validate the response format and provide helpful feedback
            validation_result = ResponseValidator.validate_chat_response(data)
            if not validation_result.is_valid:
                console.print("[warning]Response validation failed - see details below:[/warning]")
                error_message = generate_user_friendly_error_message(validation_result)
                console.print(error_message)
                console.print(f"[info]Raw response: {json.dumps(data, indent=2)}[/info]")
            
            # Update session ID and messages
            self.session_id = data.get("session_id")
            self.messages = data.get("messages", [])
            
            return data
        except Exception as e:
            console.print(f"[error]Error: {str(e)}[/error]")
            if hasattr(e, "response") and e.response is not None:
                try:
                    error_data = e.response.json()
                    console.print(f"[error]Server response: {json.dumps(error_data, indent=2)}[/error]")
                except Exception:
                    console.print(f"[error]Server response: {e.response.text}[/error]")
            return {"error": str(e)}

    def send_message_with_fallback(self, message: str) -> Dict[str, Any]:
        """Send a message with fallback to the existing RAG service.
        
        This method first tries to use the new /chat endpoint. If that fails,
        it falls back to the existing RAG service endpoint (/) for basic Q&A.
        
        Args:
            message: The message to send.
            
        Returns:
            Dict[str, Any]: The response from either the chat service or RAG fallback.
        """
        # First, try the new chat endpoint
        try:
            response = self.send_message(message)
            
            # If we get a valid response (no error key), return it
            if "error" not in response:
                return response
                
            console.print("[warning]Chat endpoint failed, trying RAG fallback...[/warning]")
            
        except Exception as e:
            console.print(f"[warning]Chat endpoint error: {str(e)}, trying RAG fallback...[/warning]")
        
        # Fallback to the existing RAG service
        return self._query_rag_service(message)
    
    def _query_rag_service(self, question: str) -> Dict[str, Any]:
        """Query the existing RAG service as fallback.
        
        Args:
            question: The question to ask the RAG service.
            
        Returns:
            Dict[str, Any]: Formatted response compatible with chat format.
        """
        url = self.endpoint  # Base endpoint for RAG service
        payload = {"question": question}
        
        try:
            # Parse the URL to get the host
            parsed_url = urllib.parse.urlparse(url)
            host = parsed_url.netloc
            
            # Get credentials from the session
            credentials = self.aws_session.get_credentials()
            if credentials is None:
                raise ValueError("No AWS credentials found. Please check your AWS configuration.")
                
            region = self.aws_session.region_name or "us-west-2"
            
            # Create a request to sign
            request = AWSRequest(
                method="POST",
                url=url,
                data=json.dumps(payload),
                headers={
                    "Host": host,
                    "Content-Type": "application/json",
                }
            )
            
            # Sign the request
            SigV4Auth(credentials, "execute-api", region).add_auth(request)
            
            # Convert to a requests request
            signed_headers = dict(request.headers)
            
            # Make the request
            response = requests.post(
                url,
                json=payload,
                headers=signed_headers
            )
            
            response.raise_for_status()
            rag_data = response.json()
            
            console.print("[info]✅ RAG service responded successfully[/info]")
            
            # Convert RAG response to chat format
            import time
            import ulid
            
            # Generate session ID if we don't have one
            if not self.session_id:
                self.session_id = f"session_{ulid.new().str.lower()}"
            
            # Create chat-compatible response
            chat_response = {
                "session_id": self.session_id,
                "messages": [
                    {
                        "message_id": f"message_{ulid.new().str.lower()}",
                        "message_type": "HUMAN",
                        "message": question,
                        "timestamp": int(time.time())
                    },
                    {
                        "message_id": f"message_{ulid.new().str.lower()}",
                        "message_type": "BOT", 
                        "message": rag_data.get("answer", "No answer provided"),
                        "timestamp": int(time.time()),
                        "intent": "QUERY",
                        "sources": []  # RAG service doesn't provide source details in this format
                    }
                ]
            }
            
            # Update our local state
            self.messages = chat_response["messages"]
            
            console.print("[info]📋 Converted RAG response to chat format[/info]")
            return chat_response
            
        except Exception as e:
            console.print(f"[error]RAG service fallback failed: {str(e)}[/error]")
            if hasattr(e, "response") and e.response is not None:
                try:
                    error_data = e.response.json()
                    console.print(f"[error]RAG service response: {json.dumps(error_data, indent=2)}[/error]")
                except Exception:
                    console.print(f"[error]RAG service response: {e.response.text}[/error]")
            
            return {"error": f"Both chat and RAG services failed. Last error: {str(e)}"}


def display_message(message: Dict[str, Any]) -> None:
    """Display a message in the console.
    
    Args:
        message: The message to display.
    """
    message_type = message.get("message_type", "SYSTEM")
    message_content = message.get("message", "")
    
    if message_type == "HUMAN":
        console.print(Panel(
            message_content,
            title="You",
            title_align="left",
            border_style="green",
            expand=False
        ))
    elif message_type == "BOT":
        # Try to render as markdown
        try:
            md = Markdown(message_content)
            console.print(Panel(
                md,
                title="Bot",
                title_align="left",
                border_style="blue",
                expand=False
            ))
        except:
            # Fallback to plain text
            console.print(Panel(
                message_content,
                title="Bot",
                title_align="left",
                border_style="blue",
                expand=False
            ))
    else:
        console.print(Panel(
            message_content,
            title="System",
            title_align="left",
            border_style="magenta",
            expand=False
        ))


def display_conversation(messages: List[Dict[str, Any]]) -> None:
    """Display the conversation history.
    
    Args:
        messages: The list of messages to display.
    """
    for message in messages:
        display_message(message)


def load_script(script_file: str) -> List[str]:
    """Load messages from a script file.
    
    Supports multiple formats:
    1. Plain text: One message per line (empty lines and lines starting with # are ignored)
    2. JSON: Array of strings or objects with 'message' field
    
    Args:
        script_file: Path to the script file
        
    Returns:
        List[str]: List of messages to send
        
    Raises:
        FileNotFoundError: If the script file doesn't exist
        ValueError: If the script file format is invalid
    """
    if not os.path.exists(script_file):
        raise FileNotFoundError(f"Script file not found: {script_file}")
    
    with open(script_file, 'r', encoding='utf-8') as f:
        content = f.read().strip()
    
    # Try to parse as JSON first
    try:
        data = json.loads(content)
        if isinstance(data, list):
            messages = []
            for item in data:
                if isinstance(item, str):
                    messages.append(item)
                elif isinstance(item, dict) and 'message' in item:
                    messages.append(item['message'])
                else:
                    raise ValueError(f"Invalid JSON format: each item must be a string or object with 'message' field")
            return [msg for msg in messages if msg.strip()]
        else:
            raise ValueError("JSON format must be an array")
    except json.JSONDecodeError:
        # Fall back to plain text format
        lines = content.split('\n')
        messages = []
        for line in lines:
            line = line.strip()
            # Skip empty lines and comments
            if line and not line.startswith('#'):
                messages.append(line)
        return messages


def run_script_mode(client: ChatClient, script_file: str, delay: float = 1.0, no_fallback: bool = False) -> None:
    """Run the chat client in script mode.
    
    Args:
        client: The chat client instance
        script_file: Path to the script file
        delay: Delay between messages in seconds
        no_fallback: If True, disable fallback to RAG service
    """
    try:
        messages = load_script(script_file)
        console.print(f"[info]Loaded {len(messages)} messages from script: {script_file}[/info]")
        
        if not messages:
            console.print("[warning]No messages found in script file.[/warning]")
            return
        
        console.print("[bold]Starting script execution...[/bold]")
        
        for i, message in enumerate(messages, 1):
            console.print(f"[info]Sending message {i}/{len(messages)}[/info]")
            
            # Display the user message
            console.print(Panel(
                message,
                title=f"Script Message {i}",
                title_align="left",
                border_style="green",
                expand=False
            ))
            
            # Send message to the chat service (with or without fallback)
            if no_fallback:
                response = client.send_message(message)
            else:
                response = client.send_message_with_fallback(message)
            
            # Display the response
            if "error" not in response:
                # Display bot responses
                bot_messages = [msg for msg in client.messages if msg.get("message_type") == "BOT"]
                if bot_messages:
                    for msg in bot_messages[-1:]:  # Display only the last bot message
                        display_message(msg)
                
                # Display session ID after first message
                if i == 1 and client.session_id:
                    console.print(f"[info]Session ID: {client.session_id}[/info]")
            else:
                console.print(f"[error]Error sending message {i}: {response.get('message', response.get('error'))}[/error]")
                console.print("[warning]Stopping script execution due to error.[/warning]")
                break
            
            # Add delay between messages (except after the last one)
            if i < len(messages) and delay > 0:
                console.print(f"[info]Waiting {delay} seconds before next message...[/info]")
                time.sleep(delay)
        
        console.print("[bold]Script execution completed![/bold]")
        if client.session_id:
            console.print(f"[info]Final session ID: {client.session_id}[/info]")
            console.print(f"[info]You can continue this conversation with: --session {client.session_id}[/info]")
            
    except FileNotFoundError as e:
        console.print(f"[error]{str(e)}[/error]")
        sys.exit(1)
    except ValueError as e:
        console.print(f"[error]Script format error: {str(e)}[/error]")
        sys.exit(1)
    except Exception as e:
        console.print(f"[error]Error running script: {str(e)}[/error]")
        sys.exit(1)


def load_config() -> Dict[str, Optional[str]]:
    """Load configuration from .env file and environment variables.
    
    Returns:
        Dict[str, Optional[str]]: Configuration values with keys: endpoint, profile, region
    """
    # Load .env file if it exists
    load_dotenv()
    
    return {
        "endpoint": os.getenv("CHAT_ENDPOINT"),
        "profile": os.getenv("AWS_PROFILE", "mlu-burner"),
        "region": os.getenv("AWS_REGION", "us-west-2"),
    }


@click.command()
@click.option(
    "--endpoint",
    "-e",
    help="The URL of the chat service endpoint. Can also be set via CHAT_ENDPOINT environment variable.",
)
@click.option(
    "--session",
    "-s",
    help="The ID of an existing session to continue.",
)
@click.option(
    "--query",
    "-q",
    help="Send a single message and exit without entering interactive mode.",
)
@click.option(
    "--script",
    help="Path to a script file containing messages to send automatically. Supports plain text (one message per line) or JSON format.",
)
@click.option(
    "--script-delay",
    default=1.0,
    type=float,
    help="Delay in seconds between script messages. Default: 1.0",
)
@click.option(
    "--history-file",
    "-h",
    default=os.path.expanduser("~/.chat_history"),
    help="The file to store command history.",
)
@click.option(
    "--profile",
    "-p",
    help="The AWS profile to use for authentication. Can also be set via AWS_PROFILE environment variable. Default: mlu-burner",
)
@click.option(
    "--region",
    "-r",
    help="The AWS region to use for authentication. Can also be set via AWS_REGION environment variable. Default: us-west-2",
)
@click.option(
    "--no-fallback",
    is_flag=True,
    help="Disable fallback to RAG service if /chat endpoint fails. Default: fallback enabled",
)
def main(endpoint: Optional[str], session: Optional[str], query: Optional[str], script: Optional[str], script_delay: float, history_file: str, profile: Optional[str], region: Optional[str], no_fallback: bool) -> None:
    """Interactive CLI for the chat service with RAG fallback support.
    
    This tool allows you to have a conversation with the RAG system through
    the chat service API. If the /chat endpoint is not yet implemented or fails,
    it can automatically fall back to the existing RAG service for basic Q&A.
    
    You can continue an existing conversation by providing a session ID, 
    run automated tests using script files, or send a single query and exit.
    
    Query Mode:
    Use --query to send a single message and exit without interactive mode:
        uv run chatbot-feature-validator.py --query "What is the weather?"
    
    Fallback behavior:
    - By default, tries /chat endpoint first, falls back to RAG service if needed
    - Use --no-fallback to disable fallback and only use /chat endpoint
    - Fallback converts RAG responses to chat format for consistency
    
    Configuration:
    The endpoint is required and must be provided via command line, environment
    variable, or .env file. Profile and region have defaults but can be overridden.
    
    Configuration priority (highest to lowest):
    1. Command line arguments (--endpoint, --profile, --region)
    2. Environment variables (CHAT_ENDPOINT, AWS_PROFILE, AWS_REGION)
    3. .env file (same variable names as environment)
    4. Defaults (profile: mlu-burner, region: us-west-2)
    
    Example .env file:
        CHAT_ENDPOINT=https://your-api.execute-api.us-west-2.amazonaws.com/live/
        AWS_PROFILE=mlu-burner
        AWS_REGION=us-west-2
    
    Script Mode:
    Use --script to run automated conversations for testing. Supports two formats:
    
    1. Plain text (one message per line):
        Hello, how are you?
        What is the weather like?
        # This is a comment and will be ignored
        Tell me a joke
    
    2. JSON format:
        [
            "Hello, how are you?",
            "What is the weather like?",
            {"message": "Tell me a joke"}
        ]
    
    Interactive Commands:
        /help - Show this help message
        /quit - Exit the chat
        /clear - Clear the screen
        /session - Show the current session ID
    """
    # Load configuration from environment and .env file
    config = load_config()
    
    # Use CLI arguments if provided, otherwise fall back to config
    final_endpoint = endpoint or config["endpoint"]
    final_profile = profile or config["profile"]
    final_region = region or config["region"]
    
    # Validate that endpoint is provided
    if not final_endpoint:
        console.print("[error]Error: Chat endpoint is required.[/error]")
        console.print("[info]Please provide the endpoint via:[/info]")
        console.print("[info]  1. Command line: --endpoint <url>[/info]")
        console.print("[info]  2. Environment variable: CHAT_ENDPOINT=<url>[/info]")
        console.print("[info]  3. .env file: CHAT_ENDPOINT=<url>[/info]")
        sys.exit(1)
    
    # Create the chat client
    client = ChatClient(final_endpoint, final_profile, final_region)
    
    # Load session if provided
    if session:
        if not client.load_session(session):
            console.print("[error]Failed to load session. Starting a new one.[/error]")
    
    # Check if we're running in query mode (single message)
    if query:
        # Load session if provided
        if session:
            if not client.load_session(session):
                console.print("[error]Failed to load session. Continuing with new session.[/error]")
        
        # Send the query
        if no_fallback:
            response = client.send_message(query)
        else:
            response = client.send_message_with_fallback(query)
        
        # Display the response
        if "error" not in response:
            bot_messages = [msg for msg in client.messages if msg.get("message_type") == "BOT"]
            if bot_messages:
                for msg in bot_messages[-1:]:
                    display_message(msg)
            
            if client.session_id:
                console.print(f"[info]Session ID: {client.session_id}[/info]")
        else:
            console.print(f"[error]Error: {response.get('message', response.get('error'))}[/error]")
            sys.exit(1)
        
        return
    
    # Check if we're running in script mode
    if script:
        run_script_mode(client, script, script_delay, no_fallback)
        return
    
    # Display welcome message for interactive mode
    console.print("[bold]Welcome to the Chat CLI![/bold]")
    console.print("Type [bold]/help[/bold] for available commands or [bold]/quit[/bold] to exit.")
    
    # Display fallback status
    if no_fallback:
        console.print("[warning]RAG service fallback is DISABLED. Only /chat endpoint will be used.[/warning]")
    else:
        console.print("[info]RAG service fallback is ENABLED. Will try existing RAG service if /chat fails.[/info]")
    
    # Display session ID if available
    if client.session_id:
        console.print(f"[info]Current session ID: {client.session_id}[/info]")
        console.print("[info]You can use this ID to resume this conversation later with --session.[/info]")
    
    # Create prompt session with history
    prompt_session: PromptSession = PromptSession(
        history=FileHistory(history_file),
        auto_suggest=AutoSuggestFromHistory(),
        style=prompt_style,
    )
    
    # Main chat loop
    while True:
        try:
            # Get user input
            user_input = prompt_session.prompt("You > ", style=prompt_style)
            
            # Process commands
            if user_input.strip() == "/quit":
                if client.session_id:
                    console.print(f"[info]Session ID: {client.session_id}[/info]")
                    console.print(f"[info]You can use this ID to resume this conversation later with --session {client.session_id}[/info]")
                console.print("[info]Goodbye![/info]")
                break
            elif user_input.strip() == "/help":
                console.print(main.__doc__)
                continue
            elif user_input.strip() == "/clear":
                console.clear()
                continue
            elif user_input.strip() == "/session":
                if client.session_id:
                    console.print(f"[info]Current session ID: {client.session_id}[/info]")
                    console.print(f"[info]To resume this conversation later, run: {sys.argv[0]} --session {client.session_id}[/info]")
                else:
                    console.print("[info]No active session.[/info]")
                continue
            elif not user_input.strip():
                continue
            
            # Send message to the chat service (with or without fallback)
            if no_fallback:
                response = client.send_message(user_input)
            else:
                response = client.send_message_with_fallback(user_input)
            
            # Display the conversation
            if "error" not in response:
                # Only display bot responses, not the user's message that was just sent
                bot_messages = [msg for msg in client.messages if msg.get("message_type") == "BOT"]
                # Get the most recent bot messages (responses to the current message)
                if bot_messages:
                    for msg in bot_messages[-1:]:  # Display only the last bot message
                        display_message(msg)
                
                # Display session ID after first message if it wasn't displayed before
                if client.session_id and not session:
                    console.print(f"[info]Session ID: {client.session_id}[/info]")
                    console.print("[info]You can use this ID to resume this conversation later with --session.[/info]")
                    session = client.session_id  # Set session to avoid showing this message again
            elif "message" in response:
                # Display friendly error message
                console.print(f"[error]{response['message']}[/error]")
            
        except KeyboardInterrupt:
            console.print("\n[info]Interrupted. Type /quit to exit.[/info]")
        except EOFError:
            console.print("\n[info]Goodbye![/info]")
            break
        except Exception as e:
            console.print(f"[error]Error: {str(e)}[/error]")


if __name__ == "__main__":
    main()
