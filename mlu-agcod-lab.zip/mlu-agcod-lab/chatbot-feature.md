# Chatbot Feature Definition

## Quick Start

Before implementing the chat feature, set up and test your environment:

1. **Configure the validator:**
   ```bash
   cp .env.example .env
   # Edit .env and update CHAT_ENDPOINT with your API Gateway URL
   ```

2. **Test the existing RAG service:**
   ```bash
   uv run chatbot-feature-validator.py
   # Ask: "What is AWS Lambda?" to verify the RAG fallback works
   ```

3. **Verify the setup:**
   - The validator should connect to your existing RAG service
   - You should get responses to questions about AWS services
   - This confirms your endpoint and AWS credentials are working

Once this works, you can start implementing the `/chat` endpoint. The validator will automatically try your new endpoint first and fall back to RAG if needed.

## Overview

We are extending the RAG capabilities of the service to support multi-turn conversations with the available documents. This will allow users to refine responses in an interactive and iterative manner. The multi-turn conversations will be persisted in a DynamoDB table that captures the conversation history and allows for a conversation to be resumed later by providing a session ID.

## Feature Requirements

### Core Requirements

1. Create a DynamoDB table to store conversation messages
2. Implement a `/chat` API endpoint that accepts and returns messages
3. Support session-based conversations with unique session IDs
4. Maintain conversation history for context in future responses
5. Integrate with existing RAG capabilities for knowledge-based responses
6. Update both service code (Lambda) and infrastructure code (CDK)

### Implementation Details

#### DynamoDB Table Design

Create a table with the following structure:

- **Table Name**: `${serviceName}-ChatSessions`
- **Primary Key**: 
  - Partition Key: `session_id` (String)
  - Sort Key: `message_id` (String)
- **Attributes**:
  - `message_type` (String): "HUMAN" or "BOT"
  - `message` (String): The message content (max 2048 characters)
  - `timestamp` (Number): Unix timestamp
  - `intent` (String): Message intent classification ("CHAT" or "QUERY")
  - `sources` (List): Source documents for RAG responses (optional)

#### Message Intent Classification

The implementation includes a message intent classifier that determines whether messages require knowledge retrieval:

- **CHAT**: Simple conversational messages (greetings, thanks, follow-ups)
- **QUERY**: Knowledge-based questions requiring RAG retrieval

This enables efficient routing to appropriate processing chains and optimizes resource usage.

#### Hybrid Chain Architecture

The chatbot uses a hybrid conversation chain that:
- Classifies message intent using an LLM-based classifier
- Routes CHAT messages to a simple conversation chain
- Routes QUERY messages to a RAG-enabled retrieval chain
- Maintains shared conversation history across both chains

#### API Endpoints

1. Implement a new `/chat` endpoint for sending messages:

- **Method**: POST
- **Request Body**:
  ```json
  {
    "session_id": "optional-session-id",
    "message": "User message here"
  }
  ```
- **Response Body**:
  ```json
  {
    "session_id": "session-id",
    "messages": [
      {
        "message_id": "message-id-1",
        "message_type": "HUMAN",
        "message": "User message here"
      },
      {
        "message_id": "message-id-2",
        "message_type": "BOT",
        "message": "Bot response here",
        "intent": "QUERY",
        "sources": [
          {
            "source": "document-id",
            "title": "Document Title",
            "page": 1
          }
        ]
      }
    ]
  }
  ```

2. Implement a `/chat/history` endpoint for retrieving session history:

- **Method**: POST
- **Request Body**:
  ```json
  {
    "session_id": "existing-session-id"
  }
  ```
- **Response Body**:
  ```json
  {
    "session_id": "existing-session-id",
    "messages": [
      {
        "message_id": "message-id-1",
        "message_type": "HUMAN",
        "message": "First user message"
      },
      {
        "message_id": "message-id-2",
        "message_type": "BOT",
        "message": "First bot response"
      },
      {
        "message_id": "message-id-3",
        "message_type": "HUMAN",
        "message": "Second user message"
      },
      {
        "message_id": "message-id-4",
        "message_type": "BOT",
        "message": "Second bot response"
      }
    ]
  }
  ```

#### Session Management

- Generate unique session IDs using ULIDs (Universally Unique Lexicographically Sortable Identifiers)
- **Package**: Use `ulid-py` (install with `pip install ulid-py`)
- Session ID format: `session_{ulid}` (e.g., `session_01h455vb4pex5vsknk084sn02q`)
- Message ID format: `message_{ulid}` (e.g., `message_01h455vb4pex5vsknk084sn02r`)
- If no session ID is provided in the request, create a new session
- If a session ID is provided, retrieve and continue that session

**ULID Benefits**:
- Time-based sorting for chronological ordering
- URL-friendly encoding
- More compact than UUIDs (26 characters)

#### Error Handling

Implement custom exception classes for specific scenarios:
- `ChatSessionNotFoundError` (404): Session doesn't exist
- `ChatMessageTooLongError` (400): Message exceeds 2048 characters
- `ChatServiceUnavailableError` (503): DynamoDB unavailable
- `GuardrailInterventionError` (400): Content blocked by guardrails
- `ChatTokenLimitExceededError` (400): Token limit exceeded
- Proper HTTP status code mapping for different error types

#### Conversation History

- Store all messages in DynamoDB for persistence
- Use LangChain's conversation memory to maintain context
- Limit conversation context to recent messages (e.g., last 10-15 messages)

## Implementation Suggestions

### Step 1: Update CDK Infrastructure

Deploy the infrastructure changes first to establish the foundation:

1. Add a DynamoDB table definition to your CDK stack
2. Configure appropriate permissions for Lambda to access DynamoDB
3. Add environment variables to Lambda for the DynamoDB table name
4. Deploy the CDK changes

**Key Configuration:**
- Table name: `${serviceName}-ChatSessions`
- Partition key: `session_id`, Sort key: `message_id`
- Grant Lambda read/write permissions
- Environment variable: `CHAT_SESSIONS_TABLE_NAME`

### Step 2: Implement Basic API Handlers

Create minimal working API endpoints to establish the interface early:

1. Define Pydantic models for chat requests/responses and history requests/responses
2. Create basic `/chat` handler that accepts messages and returns mock responses
3. Create basic `/chat/history` handler that returns empty history
4. Add basic error handling (400 for invalid requests, 500 for server errors)
5. Update main Lambda handler to route to new endpoints
6. Test the API endpoints work end-to-end

This gives you a functioning API immediately that you can iterate on.

### Step 3: Implement Data Layer

Build the persistence layer to make the API functional:

1. Create DynamoDB repository class with methods for saving and retrieving messages
2. Add ULID generation for session and message IDs
3. Implement custom exception classes (`ChatSessionNotFoundError`, `ChatMessageTooLongError`, `ChatServiceUnavailableError`, `GuardrailInterventionError`, `ChatTokenLimitExceededError`)
4. Add error handling in repository methods (DynamoDB connection issues, validation errors)
5. Update API handlers to use real data persistence with proper error responses
6. Write unit tests for models and repository

### Step 4: Implement Session Management

Add session logic to the working API:

1. Create session manager class that uses the repository
2. Add session validation and error handling (session not found, invalid session format)
3. Update `/chat` handler to create/continue sessions with error handling
4. Update `/chat/history` handler to retrieve real session data with 404 handling
5. Test session creation, continuation, and error scenarios

### Step 5: Implement Basic Chat Response

Add simple chat functionality without RAG:

1. Create a basic conversation chain that responds to messages
2. Add message length validation and error handling
3. Update `/chat` handler to generate actual responses with error handling
4. Store both user messages and bot responses in DynamoDB with retry logic
5. Test basic conversation flow and error scenarios

### Step 6: Implement LangChain Memory Integration

Connect conversation history to LangChain:

1. Create adapter between DynamoDB storage and LangChain memory
2. Configure conversation memory with sliding window (15 messages)
3. Add error handling for memory operations (corrupted history, memory limits)
4. Update conversation chain to use persistent memory with fallback handling

**Implementation Note**: Use `BaseChatMessageHistory` instead of deprecated `ConversationBufferWindowMemory`. See design.md for detailed implementation patterns.

### Step 7: Implement Message Intent Classification and Hybrid Chain

Add intelligent routing for different message types:

1. Create a `MessageIntentClassifier` class with a prompt-based approach
2. Add error handling for LLM classification failures (fallback to QUERY intent)
3. Implement the classification logic using the LLM to distinguish between:
   - **CHAT**: Simple conversational messages (greetings, thanks, follow-ups)
   - **QUERY**: Knowledge-based questions requiring RAG retrieval
4. Create a `HybridConversationChain` class that combines both chain types
5. Implement routing logic based on message intent with error handling
6. Ensure both chains share the same conversation history

### Step 8: Integrate with Existing RAG Components

Connect the chat system to your knowledge base:

1. Integrate existing RAG capabilities with the hybrid chain
2. Add error handling for RAG failures (knowledge base unavailable, no results found)
3. Update QUERY intent handling to use RAG retrieval with fallback responses
4. Add source document tracking to bot responses
5. Test knowledge-based conversations and error scenarios

## Testing Your Implementation

1. Use the provided `chatbot-feature-validator.py` script to interact with your chatbot
2. The validator includes RAG service fallback - it will try your `/chat` endpoint first, then fall back to the existing RAG service if needed
3. Test creating new sessions and continuing existing ones with `--session <session-id>`
4. Use `--no-fallback` flag to test only your `/chat` endpoint without RAG fallback
5. Verify that conversation history is maintained across sessions
6. Test integration with RAG capabilities and error scenarios
7. Ensure all unit tests pass with `brazil-build test`
8. Verify code coverage meets 80% minimum with `brazil-build test --cover`

## Workspace Structure

```
+ mlu-agcod-lab (Lab materials directory)
|-+ chat/ (Sample code directory)
|-+ chatbot-feature-validator.py (Validation script)
|-+ chatbot-feature.md (Feature description)
|-+ requirements.md (Requirements document)
|-+ design.md (Design document)
|-+ tasks.md (Implementation tasks)

+ BurnerGenaiPythonLambdaKrobrian20250711 (Brazil workspace)
|-+ BurnerGenaiPythonLambdaKrobrian20250711 (Main service package)
|-+ BurnerGenaiPythonLambdaKrobrian20250711CDK (CDK package)
|-+ BurnerGenaiPythonLambdaKrobrian20250711Data (Data package)
|-+ BurnerGenaiPythonLambdaKrobrian20250711Tests (Integration tests)
```

## Build Commands

Since we are working in a Brazil workspace we should ALWAYS use these commands:
- `brazil-build`: Fetch dependencies and build the package
- `brazil-build test`: Run unit tests
- `brazil-build test --cover`: Check code coverage (minimum 80% required)
- `brazil-build format`: Run code formatting
- `brazil-build clean`: Clean up build files

## Testing Requirements

All implementation tasks must include comprehensive unit tests with minimum 80% code coverage. Each component should be thoroughly tested with both positive and negative test cases, including error scenarios and edge cases.

## Sample API Interaction

### Request

```http
POST /chat
{
    "session_id": "session_01h455vb4pex5vsknk084sn02q",
    "message": "What documents do you have about AWS Lambda?"
}
```

### Response

```json
{
    "session_id": "session_01h455vb4pex5vsknk084sn02q",
    "messages": [
        {
            "message_id": "message_01h455vb4pex5vsknk084sn02r",
            "message_type": "HUMAN",
            "message": "What documents do you have about AWS Lambda?"
        },
        {
            "message_id": "message_01h455vb4pex5vsknk084sn02s",
            "message_type": "BOT",
            "message": "I have several documents about AWS Lambda. Lambda is a serverless compute service that lets you run code without provisioning or managing servers. Here are some key points from our documents:\n\n1. Lambda automatically scales your application by running code in response to each trigger\n2. You pay only for the compute time you consume\n3. Lambda supports multiple programming languages including Python, Node.js, Java, and more\n\nWould you like more specific information about Lambda functions, such as configuration, deployment, or best practices?"
        }
    ]
}
```

## Implementation Tips

1. Start with updating the CDK code to create the DynamoDB table
2. Use ULIDs for generating unique session and message IDs with the format `session_{ulid}` and `message_{ulid}`
3. Implement message intent classification to optimize resource usage
4. Use the hybrid chain architecture to handle both conversational and knowledge-based queries
5. Implement proper error handling with custom exception classes
6. Test incrementally as you build each component
7. Use the provided `chatbot-feature-validator.py` script to test your implementation

## Detailed Implementation Guidance

For comprehensive implementation details, code examples, and architectural patterns:
- **Requirements**: See `requirements.md` for detailed user stories and acceptance criteria
- **Architecture**: See `design.md` for technical architecture, data models, and code examples  
- **Step-by-step tasks**: See `tasks.md` for implementation sequence and testing requirements
- **Sample code**: See `chat/` directory for reference implementations

## Optional Enhancements (if time permits)

1. Add session expiration using DynamoDB TTL
2. Implement rate limiting to prevent abuse
3. Add more sophisticated conversation memory management
4. Implement conversation summarization for very long sessions
